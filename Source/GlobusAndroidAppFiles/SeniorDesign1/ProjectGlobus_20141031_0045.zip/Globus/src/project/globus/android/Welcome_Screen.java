package project.globus.android;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Welcome_Screen extends Fragment {

	private WelcomeScreenListener mListener;
	Context myContext;

	public Welcome_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	/********************************************************************************
	 * This sets up the buttons and listeners for the login butotn on the welcome screen. 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_globus__welcome__screen, container,
				false);
		Button logButton, createAccButton;
		logButton = (Button) myView.findViewById(R.id.LoginButton);
		createAccButton = (Button) myView.findViewById(R.id.CreateAccButton);
		
		logButton.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		mListener.OnWelcomeScreenSelect(0);
        	}
		});
		
		createAccButton.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		mListener.OnWelcomeScreenSelect(1);
        	}
		});

		return myView;
		
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (WelcomeScreenListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement WelcomeScreenListener");
		}
		myContext = activity.getApplicationContext();

	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface WelcomeScreenListener {
		// TODO: Update argument type and name
		public void OnWelcomeScreenSelect(int selection);
	}

}
