package project.globus.android;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
//import android.app.Fragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class Settings_Screen extends Fragment {
	
	Button leaveGroupBtn, submitButton;
	EditText newPass, verifyNewPass, groupName, googleUser, googlePass;
	String newPassString, groupNameString, googleUsername, googlePassword;
	CheckBox adminCheckbox;
	Boolean admin = false;
	Context myContext;

	private onSettingsFragInteractionListener mListener;

	public Settings_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.settings_main_screen, container, false);
		
		newPass = (EditText) myView.findViewById(R.id.passwordEditText);
		String newPassTemp = newPass.getEditableText().toString();
		
		verifyNewPass = (EditText) myView.findViewById(R.id.verifyPasswordEditText);
		String verifyNewPassTemp = verifyNewPass.getEditableText().toString();
		
		// Check to make sure new passwords match.
		if(newPassTemp == verifyNewPassTemp)
		{
			newPassString = newPassTemp;
		}
		
		groupName = (EditText) myView.findViewById(R.id.groupNameEditText);
		groupNameString = groupName.toString();
		
		googleUser = (EditText) myView.findViewById(R.id.googleUsernameEditText);
		googleUsername = googleUser.toString();
		
		googlePass = (EditText) myView.findViewById(R.id.googlePasswordEditText);
		googlePassword = googlePass.toString();
		
		adminCheckbox = (CheckBox) myView.findViewById(R.id.administratorCheckbox);
		admin = adminCheckbox.isChecked();
		
		submitButton =(Button) myView.findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO: This is where any changed settings will be submitted to the database.
					//This is where all the new settings will be submitted to the database via the variables
					//I set up.
				
					// groupNameString to DB.
					// googleUsername to DB.
					// googlePassword to DB.
					// newPassString to DB.
				
				if(admin == true)
				{
					// Admin is true to DB.
				}
			}
        });
        
        leaveGroupBtn =(Button) myView.findViewById(R.id.leaveGroup);
        leaveGroupBtn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO: This will be a database interaction piece.
			}
        });
		
		return myView;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		/*try {
			mListener = (onSettingsFragInteractionListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}*/
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	public interface onSettingsFragInteractionListener {
		public void onSettingsFragFragmentInteraction();
	}

}
