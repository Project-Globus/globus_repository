package project.globus.android;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
//import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class Google_Drive_Screen extends Fragment {

	WebView browser;
	Button btnZoomIn, btnZoomOut, btnBack, btnForward;
	Context myContext;
	
	private onGoogleDriveFragInteractListener mListener;
	
	public Google_Drive_Screen() {
		// Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_google_drive_screen, container, false);
		
		//setup the WebView object and give it the initial destination.
        browser=(WebView) myView.findViewById(R.id.webkit);
        browser.getSettings().setJavaScriptEnabled(true);
        browser.getSettings().setBuiltInZoomControls(true);
        browser.getSettings().setLoadWithOverviewMode(true);
        browser.getSettings().setUseWideViewPort(true);
        browser.setInitialScale(50);
        browser.loadUrl("https://drive.google.com");
        //browser.loadUrl("");
        //setup the callBack, so when the user clicks a link, we intercept it and kept everything
        //in the app.
        browser.setWebViewClient(new CallBack());
        
        //how buttons from zoom and forward/back.
        btnZoomIn=(Button) myView.findViewById(R.id.btnZoomIn);
        btnZoomIn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				browser.zoomIn();
			}
        });
        btnZoomOut=(Button) myView.findViewById(R.id.btnZoomOut);
        btnZoomOut.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				browser.zoomOut();
			}
        });
        btnBack=(Button) myView.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if (browser.canGoBack()) {
					browser.goBack();
				}
			}
        });
        btnForward=(Button) myView.findViewById(R.id.btnFoward);
        btnForward.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if (browser.canGoForward()) {
					browser.goForward();
				}
			}
        });
        
        return myView;
	}
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (onGoogleDriveFragInteractListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}
	
	public interface onGoogleDriveFragInteractListener {
		// TODO: Update argument type and name
		public void onGoogleDriveFragInteraction();
	}

	/*
	 * This is override, so i can intercept when a user clicks a link, so it won't leave the app.
	 */
    private class CallBack extends WebViewClient {
    	public boolean shouldOverrideUrlLoading(WebView view, String url) {
    		browser.loadUrl(url);
    		return true;
    	}
    }}
