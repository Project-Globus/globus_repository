//Project Globus Main 
//Project Globus Members: David Crane, Kelsey Crea, Jesse Miller, Taylor Olsen 
//Project Globus is a group management applications for groups to manage members and work together via phone app. 
//This project was last updated on October 30, 2014


package project.globus.android;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.os.Build;

import java.net.Socket;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.InputStreamReader;
import java.io.IOException;


/*****************************************************************************************
 * This is main starting activity (activity 1) that starts with a welcome screen. 
 * @author Team Globus 
 * comment updated October 30, 2014
 ****************************************************************************************/
public class Globus_Welcome_Screen extends Activity implements
  project.globus.android.Welcome_Screen.WelcomeScreenListener,
  project.globus.android.Create_Account_Screen.CreateAccountListener, 
  project.globus.android.Login_Screen.LoginSelectListener{
	
	private static Socket socket = null;
	private static PrintWriter toServer = null;
	private static BufferedReader fromServer = null;

	public void serverStuff(){
		System.out.println("Testint init");
		initConnection();
		System.out.println("Init successfull... or was it?!?!?!?!");
		testConnection();
	}
	
/****************************************************************************************
 * The welcome screen is the first fragment to load for the user. Go to Welcome_Screen.java 
 * to see more details.
 * 
 * Comment updated October 30, 2014
 ***************************************************************************************/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_globus__welcome__screen);
		if (savedInstanceState == null) {
			
			getFragmentManager().beginTransaction()
					.add(R.id.container, new Welcome_Screen()).commit();
		}
	}
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.globus__welcome__screen, menu);
		return true;
	}
	
	private void initConnection() {
		System.out.println("initConnection initialized... begining try/catch");
		// David: This try/catch block must be called in order to instantiate a client thread.
		try {
			socket = new Socket("ec2-54-191-216-200.us-west-2.compute.amazonaws.com", 63400);
		}
		catch (IOException e)
		{
			Toast.makeText(getBaseContext(), "This shinit aint working." , Toast.LENGTH_LONG).show();
		}	
	}
	
	private void testConnection(){
		try{
			toServer = new PrintWriter(socket.getOutputStream(), true);
			fromServer = new BufferedReader( new InputStreamReader(socket.getInputStream()));
			
			toServer.println("(o)_(o) Hello there...");
		}catch(IOException e){
			Toast.makeText(getBaseContext(), "This test aint working." , Toast.LENGTH_LONG).show();
		}
	}
	
	/********************************************************************************
	 * Yeah we haven't done anything for these button items or spoken about them....
	 * We can make these functional at some point but it's not a huge rush right now 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


	
	/********************************************************************************
	 * This is load the login fragment. For more details go to Login_Screen.java 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public void OnLoginSelect() {        
        Welcome_Screen frag = new Welcome_Screen();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.container, frag);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();	
		
	}

	
	/********************************************************************************
	 * This will load the 'Create a new account' fragment. For more details 
	 * go to Create_Account_Screen.java
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public void OnCreateAccountSelect() {        
        Welcome_Screen frag = new Welcome_Screen();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.container, frag);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();	
	}

	
	
	/*******************************************************************************
	 * This will determine which fragment (login or create a new account) will be loaded 
	 * depending what selection is passed into this function. 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public void OnWelcomeScreenSelect(int selection) {
		if(selection == 0){
			Login_Screen frag = new Login_Screen();
	        FragmentTransaction transaction = getFragmentManager().beginTransaction();

	        // Replace whatever is in the fragment_container view with this fragment,
	        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.container, frag);
	        transaction.addToBackStack(null);
	        // Commit the transaction
	        transaction.commit();
		}
		else if(selection == 1){
			Create_Account_Screen frag = new Create_Account_Screen();
	        FragmentTransaction transaction = getFragmentManager().beginTransaction();

	        // Replace whatever is in the fragment_container view with this fragment,
	        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.container, frag);
	        transaction.addToBackStack(null);
	        // Commit the transaction
	        transaction.commit();
		}
	}
	
	public PrintWriter getToServer() {
		return toServer;
	}
	
	public Socket getSocket() {
		return socket;
	}
	
	public BufferedReader getFromServer() {
		return fromServer;
	}
	
	class globusThread implements Runnable{
		
	}
	
}
