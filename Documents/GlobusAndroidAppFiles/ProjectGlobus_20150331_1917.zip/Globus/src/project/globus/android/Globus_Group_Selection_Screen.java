package project.globus.android;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


/************************************************************************
 * This is the second activity (activity 2) that starts by loading the  *
 * group selection page                                                 *
 * @author Team Globus                                                  *
 * comment updated November 10, 2014                                    *
 ************************************************************************/

public class Globus_Group_Selection_Screen extends Activity implements
	project.globus.android.Group_Select_Screen.GroupSelectListener,
	project.globus.android.Join_Group_Screen.JoinGroupListener,
	project.globus.android.Create_Group_Screen.CreateGroupListener{	

	
	public String getMemberID(){
		return getIntent().getStringExtra("membership");
	}
    
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_group__screen);
		
		if(savedInstanceState == null) {
			Group_Select_Screen newFrag = new Group_Select_Screen();
			//newFrag.setArguments(getIntent().getExtras());
			getFragmentManager().beginTransaction()
				.add(R.id.container2, newFrag).commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		getMenuInflater().inflate(R.menu.group__screen, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if(id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void OnGroupScreenSelect(int selection) {
			if(selection == 0) {
				Join_Group_Screen frag = new Join_Group_Screen();
				FragmentTransaction transaction = getFragmentManager().beginTransaction();
				transaction.replace(R.id.container2, frag);
				transaction.addToBackStack(null);
				transaction.commit();
			} else {
				Create_Group_Screen frag = new Create_Group_Screen();
				FragmentTransaction transaction = getFragmentManager().beginTransaction();
				transaction.replace(R.id.container2, frag);
				transaction.addToBackStack(null);
				transaction.commit();
			}
	}

	@Override
	public void OnJoinGroup() {
		Join_Group_Screen frag = new Join_Group_Screen();
		FragmentTransaction transaction = getFragmentManager().beginTransaction();
		transaction.replace(R.id.container2, frag);
		transaction.addToBackStack(null);
		transaction.commit();	
	}

	@Override
	public void OnCreateGroup() {
		Create_Group_Screen frag = new Create_Group_Screen();
		FragmentTransaction transaction = getFragmentManager().beginTransaction();
		transaction.replace(R.id.container2, frag);
		transaction.addToBackStack(null);
		transaction.commit();
		
	}
}
