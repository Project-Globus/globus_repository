package project.globus.android;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Create_Account_Screen extends Fragment {

	//Declare Buttons and Text fields we will use.
	private EditText nameText, emailText, passText;
	private Button submitB, cancelB;
	private CreateAccountListener mListener;
	Context myContext;

	public Create_Account_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	}
	
	
	/********************************************************************************
	 * This creates the buttons and text fields that the user will interact with on the 
	 * create new account fragment. The user will have a submit and cancel button which 
	 * both have listeners and name, email, and password text fields they can enter 
	 * information in. 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_create__account__screen,
				container, false);
		
		//submitB is attatched to the submit button in the fragment.
		//when it is pressed, the app will check to see if the given 
		//email hasn't been used yet, and it will add the user to the 
		//database if it hasn't. 
		submitB = (Button) myView.findViewById(R.id.yesButton);
		
		//cancelB is attached to the cancel button in the fragment.
		//as you might guess, the soul purpose of this button is to 
		//back out to the welcome screen
		cancelB = (Button) myView.findViewById(R.id.noButton);
		
		//These text fields are where the user enters in his/her desired
		//name, email and password for the new account
		nameText = (EditText) myView.findViewById(R.id.nameInput); 
		emailText = (EditText) myView.findViewById(R.id.EAInput); 
		passText = (EditText) myView.findViewById(R.id.passInput); 
		
		submitB.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		//TODO: db talking stuff 
        		/*************
        		 * David,
        		 * This is where we have more database
        		 * related code. When this button is clicked,
        		 * we will need to run a query to see if there
        		 * is a user in the system with the
        		 * same email address that the user
        		 * wishes to use for their account. If there is,
        		 * the system will tell the user that the email
        		 * is already in use, and that the user needs to
        		 * enter in a different email. 
        		 * If the given email hasn't been used before,
        		 * the app needs to add a new entry into the user table,
        		 * setting the name, email and password fields to whatever
        		 * the user has put in. For now, there is nothing that
        		 * checks to see if the credentials are valid,
        		 * but we can add that in later.
        		 * 
        		 */
        		
        		//TODO: the following comment
        		/********************************************
        		 * NOTE: I don't believe it would be difficult
        		 * to add a confirm email and password element to 
        		 * this fragment. To do this, I would make the 
        		 * "submit" button into a "next" button,
        		 * after which we will store the entered email and
        		 * password, empty those text fields, change the
        		 * Email and Password titles to "Confirm Email" and
        		 * "Confirm Password" and change the "Next" button to
        		 * say "Submit" again. Then, after re entering the 
        		 * email and password, the user would hit the submit
        		 * button and the app would check to make sure the 
        		 * credentials are the same as the initialy entered
        		 * credentials. I would do this now, but I'm running
        		 * low on time.
        		 */
        		
        		//These strings contain whatever the user
        		//entered in for his/her desired name, email
        		//and password.
        		String userN = nameText.getEditableText().toString();
        		String userE = emailText.getEditableText().toString();
        		String userP = passText.getEditableText().toString();
        		
        		//Bool value reflecting on whether or not the desired
        		//credentials are currently not being used, and are valid.
        		//Until database code has been added, this has been set to 
        		//default to true.
        		boolean uniqueCreds = true;
        		
        		if(uniqueCreds){
        			//credentials valid. App adds new user entry to database, informs user of success
        			//and returns to the welcome screen.
        			
        			//!!!! here is where we add the new user entry !!!!
        			Toast.makeText(myContext, "User name valid. Account created!" , Toast.LENGTH_LONG).show();
            		mListener.OnCreateAccountSelect();

        		}
        		else{
        			//Credentials invalid. App informs user and does nothing.
        			Toast.makeText(myContext, "User name already in use. Please use different email." , Toast.LENGTH_LONG).show();

        		}
        		
        	}
		});
		
		cancelB.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		//as stated above. Upon being clicked, the app displays the welcome screen.
        		mListener.OnCreateAccountSelect();
        	}
		});
		
		return myView;
	}

	

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (CreateAccountListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement Create_Account_Listener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface CreateAccountListener {
		// TODO: Update argument type and name
		public void OnCreateAccountSelect();
	}

}
