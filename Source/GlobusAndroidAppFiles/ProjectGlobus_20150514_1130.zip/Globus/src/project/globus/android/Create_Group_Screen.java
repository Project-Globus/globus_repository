package project.globus.android;

import java.io.IOException;

import project.globus.android.Group_Select_Screen.groupEntity;
import project.globus.android.Login_Screen.LoginSelectListener;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Create_Group_Screen extends Fragment {

	private EditText newGroupName, userEmail, psswd, verifypsswd;
	private Button submitbtn;
	private CreateGroupListener mListener;
	Context myContext;
    Globus_Group_Selection_Screen groupCreateActivity = (Globus_Group_Selection_Screen)getActivity();

	public Create_Group_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.groupselect_create__group__screen, container, false);
		
		newGroupName = (EditText) myView.findViewById(R.id.newGroupNameEditText);
		//TODO: Change userEmail so that it will record the Group description instead.
		userEmail = (EditText) myView.findViewById(R.id.userEmailEditText);
		psswd = (EditText) myView.findViewById(R.id.psswdEditText);
		verifypsswd = (EditText) myView.findViewById(R.id.verifypsswdEditText);
		submitbtn = (Button) myView.findViewById(R.id.submitNewGroupBtn);
		
		submitbtn.setOnClickListener(new OnClickListener() {
			@Override 
			public void onClick(View view) {

        		if(newGroupName.getText().toString().matches("") || psswd.getText().toString().matches("") || !(psswd.getText().toString().matches(verifypsswd.getText().toString()))) {
        			Toast.makeText(myContext, "Please check your fields. You must provide a group name and you must give, and verify, your password." , Toast.LENGTH_LONG).show();
        			return;
        		}
				
				try{
					System.out.println("Try block started.");
					//Server Code Time ************************************************************************
					//Creating a group requires to be logged in,  the keyword "create" and the group name, description, and password.
					String allText = new String("create;~;" + newGroupName.getEditableText().toString() + ";~;" +  "This group does stuff... bitch." 
																										+ psswd.getEditableText().toString());
					System.out.println(allText);
					System.out.println("Sending text.");
					//groupCreateActivity.getToServer().println(allText);
					System.out.println("sent to db");

					//groupCreateActivity.setWriterClosed();

					System.out.println("writer closed");

					//String response = groupCreateActivity.getFromServer().readLine();

					//String [] splitResponse = response.split(";~;");
					//System.out.println(response);


//					//TODO: while loop for error correction 
//					if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
//						Toast.makeText(myContext, "Error retrieving group list. oops..." , Toast.LENGTH_LONG).show();
//					} else{
//						for(int i = 1; i < splitResponse.length; ){
//							groupEntity g = new groupEntity(splitResponse[i], splitResponse[i + 3], splitResponse[i + 1]);
//							addGrpToList(g);
//							i += 7;
//						}
//					}

				
				
				}
				//catch (IOException e){}
				finally{}		
						
				//No More Server Code *********************************************************************
				
				Boolean credsValid = true;
				if(credsValid == true) {
					Intent intent = new Intent(getActivity(), Globus_Application.class);
        			getActivity().startActivity(intent);
					Toast.makeText(myContext, "Credentials are valid!! New Group sucessfull." , Toast.LENGTH_LONG).show();
				}
				else Toast.makeText(myContext, "Credentials are NOT VALID. New Group not sucessfull." , Toast.LENGTH_LONG).show();
			}
		});
		return myView;
	}
	

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (CreateGroupListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}


	public interface CreateGroupListener {
		public void OnCreateGroup();
	}

}
