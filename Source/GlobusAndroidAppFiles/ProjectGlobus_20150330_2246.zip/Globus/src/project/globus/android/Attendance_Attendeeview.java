package project.globus.android;

import java.util.ArrayList;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
//import android.app.Fragment;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class Attendance_Attendeeview extends Fragment {

	private ListView attdncelv;
	private AttdnceSelectListener mListener;
	Context myContext;
	ArrayList<attendeeEntity> attdnceList = new ArrayList<attendeeEntity>();
	private attdnceAdapter m_adapter;

	public Attendance_Attendeeview() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		attendeeEntity aeT = new attendeeEntity("Taylor");
		attendeeEntity aeD = new attendeeEntity("David");
		attendeeEntity aeJ = new attendeeEntity("Jesse");
		attendeeEntity aeK = new attendeeEntity("Kelsey");
		addAttendeeToList(aeT);
		addAttendeeToList(aeD);
		addAttendeeToList(aeJ);
		addAttendeeToList(aeK);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_attendance__attendeeview, container, false);
		this.m_adapter = new attdnceAdapter(myContext, R.layout.attendance_attendee_listview, attdnceList);
		attdncelv = (ListView) myView.findViewById(R.id.attendeeList);
		attdncelv.setAdapter(this.m_adapter);
		m_adapter.notifyDataSetChanged();
		
		//TODO: this is where the checkbox listener will be implemented
		
		return myView;
	}

	

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		/*try {
			mListener = (AttdnceSelectListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}*/
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	public interface AttdnceSelectListener {
		// TODO: Update argument type and name
		public void onFragmentInteraction(Uri uri);
	}
	
	
	public void addAttendeeToList(attendeeEntity aE){
		attdnceList.add(new attendeeEntity(aE.getAttendeeName()));
	}
	
	public class attendeeEntity{
		private String name;
		
		public attendeeEntity(String nme){
			name = nme;
		}
		
		public void setAttendeeName (String nme) {name = nme;}
		public String getAttendeeName() {return name;}
	}
	
	private class attdnceAdapter extends ArrayAdapter<attendeeEntity> {
		
		private ArrayList<attendeeEntity> items;
		
		public attdnceAdapter(Context context, int textViewResourceId, ArrayList<attendeeEntity> items) {
			super(context, textViewResourceId, items);
			this.items = items;
		}
		
		//TODO:
		//Need to add checkbox but make sure database can work with just a checkbox for each member in the event
		@Override 
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView; 
			if(v==null) {
				LayoutInflater vi = LayoutInflater.from(this.getContext());
				v = vi.inflate(R.layout.attendance_attendee_listview, null);
			}
			attendeeEntity atndeE = items.get(position);
			if(atndeE != null){
				TextView nameText = (TextView) v.findViewById(R.id.attendeeNameText);
				if(nameText != null){
					nameText.setText(atndeE.getAttendeeName());
				}
			}
			return v;
		}
		
	}
	

}





















