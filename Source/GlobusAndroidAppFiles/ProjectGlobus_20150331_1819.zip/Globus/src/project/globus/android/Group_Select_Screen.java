package project.globus.android;

import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Group_Select_Screen extends Fragment {

	private ListView joinedGrouplv;
	private Button createGroupbtn, joinGroupbtn;
	private GroupSelectListener mListener;
	Context myContext;
	ArrayList<groupEntity> grpList = new ArrayList<groupEntity>();
    private groupAdapter m_adapter;
    private String userID = "null";
	
    Globus_Group_Selection_Screen groupListActivity = (Globus_Group_Selection_Screen)getActivity();
    
    
	public Group_Select_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		System.out.println("ON CREATE REACHED");
		groupEntity g = new groupEntity("Globus Dev Team", "What better way to work on a project than to work with it.", "1000");
		addGrpToList(g);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_group__select__screen, container, false);
		this.m_adapter = new groupAdapter(myContext, R.layout.joined_group_listview, grpList);
		joinedGrouplv = (ListView) myView.findViewById(R.id.joinedGroups);
		joinedGrouplv.setAdapter(this.m_adapter);
        m_adapter.notifyDataSetChanged();
		//String membership = groupListActivity.userID;
		
		createGroupbtn = (Button) myView.findViewById(R.id.createGroupBtn);
		joinGroupbtn = (Button) myView.findViewById(R.id.joinGroupBtn);
		System.out.println("Beginning Try Catch.");
		userID = ((Globus_Group_Selection_Screen)getActivity()).getMemberID();
		try{
			System.out.println("Try block started.");
			//Server Code Time ************************************************************************
			String allText = new String("membership;~;"+  userID);
			System.out.println(allText);
			System.out.println("Sending text.");
			//groupListActivity.getToServer().println(allText);
			System.out.println("sent to db");

			//groupListActivity.setWriterClosed();

			System.out.println("writer closed");

			//String response = groupListActivity.getFromServer().readLine();

			//String [] splitResponse = response.split(";~;");
			//System.out.println(response);


			//TODO: while loop for error correction 
		/*	if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
				Toast.makeText(myContext, "Error retrieving group list. oops..." , Toast.LENGTH_LONG).show();
			} else{
				for(int i = 1; i < splitResponse.length; ){
					groupEntity g = new groupEntity(splitResponse[i], splitResponse[i + 3], splitResponse[i + 1]);
					addGrpToList(g);
					i += 7;
				}
			}

		*/
		
		}
		//catch (IOException e){}
		finally{}		
				
		//No More Server Code *********************************************************************
		
		createGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				mListener.OnGroupScreenSelect(1);
			}
		});
		
		joinGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				mListener.OnGroupScreenSelect(0);
			}
		});
		
		joinedGrouplv.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				Intent intent = new Intent(getActivity(), Globus_Application.class);
    			getActivity().startActivity(intent);
			}
		});
		
		
		return myView;		
	}
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (GroupSelectListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement GroupSelectListener");
		}
		myContext = activity.getApplicationContext();
	}
	
	@Override 
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}
	
	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface GroupSelectListener {
		public void OnGroupScreenSelect(int selection);
	}
	
	public void addGrpToList(groupEntity gE){
		grpList.add(new groupEntity(gE.getName(), gE.getDescription(), gE.getGrpID()));
	}
	
	public class groupEntity{
		
		
		private String name;
		private String description;
		private String grp_id;
		
		public groupEntity(String nme, String desc, String grpID){
			name = nme;
			description = desc; 
			grp_id = grpID;
		}

		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setGroupID(String grpID){grp_id = grpID;}
		
		public String getName(){return name;}
		public String getDescription(){return description;}
		public String getGrpID(){return grp_id;}
	}

private class groupAdapter extends ArrayAdapter<groupEntity> {

    private ArrayList<groupEntity> items;

    public groupAdapter(Context context, int textViewResourceId, ArrayList<groupEntity> items) {
            super(context, textViewResourceId, items);
            this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                LayoutInflater vi = LayoutInflater.from(this.getContext());
                v = vi.inflate(R.layout.joined_group_listview, null);
            }
            groupEntity grpE = items.get(position);
            if (grpE != null) {
                    TextView nameText = (TextView) v.findViewById(R.id.grpNameText);
                    TextView descText = (TextView) v.findViewById(R.id.grpDescText);
                    if( nameText != null){
                    	nameText.setText(grpE.getName());
                    }
                    if( descText != null){
                    	descText.setText(grpE.getDescription());
                    }
            }
            return v;
    }
}
}