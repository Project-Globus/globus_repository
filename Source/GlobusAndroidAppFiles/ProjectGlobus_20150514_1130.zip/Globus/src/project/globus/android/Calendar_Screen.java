package project.globus.android;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import com.roomorama.caldroid.CaldroidFragment;
import com.roomorama.caldroid.CaldroidListener;

import project.globus.android.Calendar_Event_ChildList;
import project.globus.android.Calendar_Event_ParentList;
import project.globus.android.Calendar_ExpandableListAdapter;
import android.app.Activity;
import android.app.Dialog;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This fragment creates a calendar view, and populates it via a CalendarContract. 
 * This CalendarContract pulls calendars from the phone, which are being created/updated
 * via the event database.
 */
public class Calendar_Screen extends Fragment {


	Button addNewEventBtn;
	Button createEve;
	Button nxtBtn;
	Button cancelCreate;
	TextView dateBoard;
	ExpandableListView eventLV;

	//parent and child array lists for keeping track 
	//of which events need to be displayed on the screen
	ArrayList<Calendar_Event_ParentList> currentEvent = new ArrayList<Calendar_Event_ParentList>();
	ArrayList<Object> currentDesc = new ArrayList<Object>();
	
	//parent and child array lists for keeping track 
	//of all events known by the application
	ArrayList<Calendar_Event_ParentList> groupEvents = new ArrayList<Calendar_Event_ParentList>();
	ArrayList<Object> eventDesc = new ArrayList<Object>();
	
	ArrayList<attendeeEntity> attList = new ArrayList<attendeeEntity>();
    private attendeeAdapter a_adapter;
    
	final SimpleDateFormat eveFormat = new SimpleDateFormat("MM/dd/yy, HH:mm");
	CaldroidFragment caldroidFragment = new CaldroidFragment();
	Calendar_ExpandableListAdapter mNewAdapter = 
			new Calendar_ExpandableListAdapter(currentEvent, currentDesc);
	
	Globus_Service mService = new Globus_Service();
	boolean mBound = false;
	
	
	
	//Set group id passed from last activity.
	private String groupID = ((Globus_Application)getActivity()).getGroupID();;
	Context myContext;
	

	private onCalendarFragInteractListener mListener;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (getArguments() != null) {
			//mParam1 = getArguments().getString(ARG_PARAM1);
			//mParam2 = getArguments().getString(ARG_PARAM2);
		}
		
//		//****TEST CODE START*****//
//		System.out.println("creating test groups...");
//		Calendar_Event_ParentList testP1 = 
//					new Calendar_Event_ParentList("Group Meeting", new Date(1428361200000L), new Date(1428361200000L), "123", "123");
//		Calendar_Event_ChildList testC1 = 
//					new Calendar_Event_ChildList("Make sure you're here!! We got a lot to do.");
//		Calendar_Event_ParentList testP2 = 
//				new Calendar_Event_ParentList("Picnic!", new Date(1428363000000L), new Date(1428363000000L), "123", "123");
//		Calendar_Event_ChildList testC2 = 
//				new Calendar_Event_ChildList("Don't want to miss this. Jimmy's brining his famous sandwiches today!");
//		ArrayList<Calendar_Event_ChildList> c1 = new ArrayList<Calendar_Event_ChildList>();
//		ArrayList<Calendar_Event_ChildList> c2 = new ArrayList<Calendar_Event_ChildList>();
//		
//		//****TEST CODE END******//
//		
//		groupEvents.add(testP1);
//		groupEvents.add(testP2);
//		c1.add(testC1);
//		c2.add(testC2);
//		eventDesc.add(c1);
//		eventDesc.add(c2);
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.calendar_main_screen, container,
				false);
		
		calCreate(myView);
		getEvents();
		eventLV = (ExpandableListView) myView.findViewById(R.id.eventsListView);
		
		
		  mNewAdapter
		    .setInflater(
		      (LayoutInflater) myContext.getSystemService(myContext.LAYOUT_INFLATER_SERVICE),
		      this.getActivity());
		eventLV.setAdapter(mNewAdapter);
		 
		  
		addNewEventBtn = (Button) myView.findViewById(R.id.calNewEveBtn);
		addNewEventBtn.setOnClickListener(new OnClickListener() {
       	 
 		  @Override
 		  public void onClick(View arg0) {
 			  createEventInfo();
 		  }
 		});
		
		return myView;
	}
	
	/**
	 * Creates a new instance of the Caldroid calendar object
	 * */
	private void calCreate(View myView){
		Bundle args = new Bundle();
		Calendar cal = Calendar.getInstance();
		args.putInt(CaldroidFragment.MONTH, cal.get(Calendar.MONTH) + 1);
		args.putInt(CaldroidFragment.YEAR, cal.get(Calendar.YEAR));
		args.putBoolean(CaldroidFragment.SIX_WEEKS_IN_CALENDAR, true);
		caldroidFragment.setArguments(args);
		android.support.v4.app.FragmentTransaction t = getFragmentManager().beginTransaction();
		t.replace(R.id.calendar1, caldroidFragment);
		t.commit();
				
		dateBoard= (TextView) myView.findViewById(R.id.calDateBoard);
		
		// Setup listener
		caldroidFragment.setCaldroidListener(new CaldroidListener() {
			@Override
			public void onSelectDate(Date date, View view) {
				String currentDate = eveFormat.format(date);
				if(!dateBoard.getText().toString().matches(currentDate)){
					dateBoard.setText(currentDate);
					updateEventsList(date);					
				}
			}
			@Override
			public void onChangeMonth(int month, int year) {
			}

			@Override
			public void onLongClickDate(Date date, View view) {
				dateBoard.setText(eveFormat.format(date));
			}
			@Override
			public void onCaldroidViewCreated() {
				dateBoard.setText("Select Date to View Events");
			}
		});
	}
	
	/**
	 * Queries the database for a list of all events
	 * listed for a group, and adds them to the list
	 * of known events.
	 * */
	private void getEvents(){
		
		
		System.out.println("Beginning Try Catch.");
		String response = new String();
		
		try{
			System.out.println("Try block started.");
			
			String allText = new String("getEvents;~;"+  groupID);
			System.out.println(allText);
			System.out.println("Sending text.");
			mService.getToServer().println(allText);
			System.out.println("sent to db");

			mService.setWriterClosed();

			System.out.println("writer closed");
			System.out.println("Reading Lines!!!");
			response = mService.getFromServer().readLine();
			System.out.println(response + "Responding!!!!");
			String [] splitResponse = response.split(";~;");
			System.out.println(response + "Responding!!!!");


			//TODO: while loop for error correction 
			if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
				Toast.makeText(myContext, "Error retrieving group list. oops..." , Toast.LENGTH_LONG).show();
			} else{
				for(int i = 1; i < splitResponse.length; ){
					Calendar_Event_ParentList eP = new Calendar_Event_ParentList(splitResponse[i+1], 
													new Date(Long.parseLong(splitResponse[i+3])), 
													new Date(Long.parseLong(splitResponse[i+4])),
													splitResponse[i], splitResponse[i+5]);
					Calendar_Event_ChildList eC = new Calendar_Event_ChildList(splitResponse[i+2]);

					if(!groupEvents.contains(eP)){
						groupEvents.add(eP);
						eventDesc.add(eC);}
					i += 6;
				}
				updateCalEvents();
			}	
			
		}
		catch (IOException e){}
		finally{}	
	}
	
	/**
	* Updates the events that need to be displayed
	* based off of what date the user has selected
	*/
	private void updateEventsList(Date current){
		currentEvent.clear();
		currentDesc.clear();
		for(int i = 0; i < groupEvents.size(); i++){
			Calendar_Event_ParentList eve = groupEvents.get(i);
			System.out.println();
			if(justDay(eve.getStDate()).getTime() == justDay(current).getTime()){
				currentEvent.add(eve);
				currentDesc.add(eventDesc.get(i));
			}
		}
		mNewAdapter.notifyDataSetChanged();
	}
	
	/**	
	* Colors in calendar dates based off of current list of group events
	*/
	private void updateCalEvents() {
		ArrayList<Date> dates = new ArrayList<Date>();
		Date day = new Date();
		for(int i = 0; i < groupEvents.size(); i++){
			day = justDay(groupEvents.get(i).getStDate());
			
	        if(!dates.contains(day))
	        		dates.add(day);
		}
		
		for(int j = 0; j < dates.size(); j++){
			if (caldroidFragment != null) {
				caldroidFragment.setBackgroundResourceForDate(R.color.caldroid_holo_blue_dark,
						dates.get(j));
				caldroidFragment.setTextColorForDate(R.color.caldroid_white, dates.get(j));
			}
		}
	}
	
	/**
	* Takes in a Date object, containing both a date and time, 
	* and returns the date. The new time is 00:00:00
	*/
	private Date justDay(Date d){
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
	}

	
	/**
	* Creates a dialog that prompts the user for 
	* the beginning and ending date and time for
	* a new event, as well as the name and 
	* description for the event. It then
	* stores this in an eventItem and sends it
	* off to "addEventAtt"
	*/
	public void createEventInfo(){
			// custom dialog
			final Dialog dialog = new Dialog(getActivity());
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.calendar__add__event);
			
			// set the custom dialog components
			nxtBtn = (Button) dialog.findViewById(R.id.newEveNxtBtn);
			cancelCreate = (Button) dialog.findViewById(R.id.newEveCancelBtn);
			final EditText stTime = (EditText) dialog.findViewById(R.id.timeStText);
			final EditText stDte = (EditText) dialog.findViewById(R.id.dateStText);
			final EditText enTime = (EditText) dialog.findViewById(R.id.timeEnText);
			final EditText enDte = (EditText) dialog.findViewById(R.id.dateEnText);
			final EditText nme = (EditText) dialog.findViewById(R.id.newEveTitle);
			final EditText desc = (EditText) dialog.findViewById(R.id.editText1);
			
			nxtBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					SimpleDateFormat sdf = new SimpleDateFormat("hh:mm DD/MM/YY");
					eventItem eveI;
			        Date stDate = null;
			        Date enDate = null;
			        try {
			            stDate = sdf.parse(stTime.getEditableText().toString() + " " + stDte.getEditableText().toString());
			            enDate = sdf.parse(enTime.getEditableText().toString() + " " + enDte.getEditableText().toString());
			            eveI = new eventItem(stDate, enDate, "eve ID", nme.getEditableText().toString(), 
			            		desc.getEditableText().toString(), "Cal Id");
			            dialog.dismiss();
			            addEventAtt(eveI);
			        } catch (ParseException e) {
						Toast.makeText(myContext, "Date and Time Error! Please enter in time and date as follows: 12:00 01/01/01" , Toast.LENGTH_LONG).show();
			        }
										
				}
			});
			
			// if cancel button is clicked, close the custom dialog
			cancelCreate.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.dismiss();
				}
			});
			
			dialog.show();
		
	}
	
	/**
	* Creates a new dialog that keeps track of the
	* event previously created in "createEventInfo"
	* and allows the user to select who all is 
	* attending the event. After the user has selected
	* this, it sends the eventItem to "sendEvent"
	*/
	public void addEventAtt(eventItem mssge){
		final Dialog dialog = new Dialog(getActivity());
		final eventItem eve = mssge;
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.calendar_add_event_attendees);

		// set the custom dialog components
		final Button addAtt = (Button) dialog.findViewById(R.id.addAttBtn);
		Button canAtt = (Button) dialog.findViewById(R.id.addAttCnclBtn);
		ListView attListV = (ListView) dialog.findViewById(R.id.grpUserList);
		getAttendeeList();
		a_adapter = new attendeeAdapter(this.myContext, R.layout.calendar_add_event_attendees, attList);
		attListV.setAdapter(a_adapter);
		// if cancel button is clicked, close the custom dialog
		addAtt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				sendEvent(eve);
				dialog.dismiss();
			}
		});
		
		canAtt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				attList.clear();
				dialog.dismiss();
			}
		});
		
		attListV.setOnItemClickListener(new OnItemClickListener() {
			   public void onItemClick(AdapterView<?> parent, View view,
					     int position, long id) {
				   	if(a_adapter.anySelected())
				   		addAtt.setText("Add");
				   	else
				   		addAtt.setText("Skip");
			   }
		});
		
		dialog.show();
		
	}
	
	/**
	* Queries the database to compile a list of
	* all current members of the group. This is 
	* used by "addEventAtt" to provide the user
	* with such a list.
	**/
	public void getAttendeeList(){		
		System.out.println("Beginning Try Catch.");
		String response = new String();
		
		try{
			System.out.println("Try block started.");
			
			String allText = new String("getmembers;~;"+  groupID);
			System.out.println(allText);
			System.out.println("Sending text.");
			mService.getToServer().println(allText);
			System.out.println("sent to db");

			mService.setWriterClosed();

			System.out.println("writer closed");
			System.out.println("Reading Lines!!!");
			response = mService.getFromServer().readLine();
			System.out.println(response + "Responding!!!!");
			String [] splitResponse = response.split(";~;");


			//TODO: while loop for error correction 
			if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
				Toast.makeText(myContext, "Error retrieving group list. oops..." , Toast.LENGTH_LONG).show();
			} else{
				for(int i = 1; i < splitResponse.length; ){
					attendeeEntity att = new attendeeEntity(splitResponse[i+1], splitResponse[i+3], splitResponse[i], false);
					if(!attList.contains(att))
						attList.add(att);
					i += 4;
				}
			}	
			
		}
		catch (IOException e){}
		finally{}
	}

	/**
	 * Updates the database with a new event,
	 * and prompts the app to update it's list
	 * of events.
	 * */
	public void sendEvent(eventItem mssge){
		System.out.println("Beginning Try Catch.");
		String response = new String();
		ArrayList<attendeeEntity> attendees = a_adapter.getSelectedUsers(); 
		
		try{
			System.out.println("Try block started.");
			
			String allText = new String("addEvent;~;"+ groupEvents.get(0).getCalID()  + ";~;" 
										+ Long.toString(mssge.getTimeStart().getTime()) + ";~;" 
										+ Long.toString(mssge.getTimeEnd().getTime()) + ";~;"
										+ mssge.getName() + ";~;" + mssge.getDescription());
			System.out.println(allText);
			System.out.println("Sending text.");
			mService.getToServer().println(allText);
			System.out.println("sent to db");

			mService.setWriterClosed();

			System.out.println("writer closed");
			System.out.println("Reading Lines!!!");
			response = mService.getFromServer().readLine();
			System.out.println(response + "Responding!!!!");
			String [] splitResponse = response.split(";~;");


			//TODO: while loop for error correction 
			if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
				Toast.makeText(myContext, "Error retrieving group list. oops..." , Toast.LENGTH_LONG).show();
			} 
			else{
				getEvents();
			}
			
		}
		catch (IOException e){}
		finally{}
		
	}
	// TODO: Rename method, update argument and hook method into UI event
	
	public void onButtonPressed(Uri uri) {
		if (mListener != null) {
			mListener.onCalendarFragInteraction(uri);
		}
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (onCalendarFragInteractListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	public interface onCalendarFragInteractListener {
	
		public void onCalendarFragInteraction(Uri uri);
	}
	
	/**
	 * This class defines the structure for
	 * an event. This class is used mainly
	 * for the creation of new events.
	 * */
	public class eventItem{
		private String event_id;
		private String name;
		private String description;
		private String cal_id;
		private Date time_start;
		private Date time_end;
		

		public eventItem(Date sD, Date eD, String evID, String nme, String desc, String calID){
			time_start = sD;
			time_end = eD;
			event_id = evID;
			name = nme;
			description = desc; 
			cal_id = calID;
		}

		public void setEventID(String evID){event_id = evID;}
		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setCalID(String calID){cal_id = calID;}
		public void setTimeStart(Date d){time_start = d;}
		public void setTimeEnd(Date d){time_end = d;}
		

		public String getEventID(){return event_id;}
		public String getName(){return name;}
		public String getDescription(){return description;}
		public String getCalID(){return cal_id;}
		public Date getTimeStart(){return time_start;}
		public Date getTimeEnd(){return time_end;}
		

	}

	/**
	 * This class defines the structure for
	 * an "attendee" (I.E. a member of the
	 * current group). It also keeps track of
	 * whether or not the attendee has been
	 * selected as "going" to an event that's
	 * being created.
	 * */
	public class attendeeEntity{
		
		
		private String name;
		private String description;
		private String usr_id;
		private boolean selected;
		
		public attendeeEntity(String nme, String desc, String usrID, boolean slct){
			name = nme;
			description = desc; 
			usr_id = usrID;
			selected = slct;
		}

		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setUserID(String usrID){usr_id = usrID;}
		public void setSelect(boolean slct){selected = slct;}
		
		public String getName(){return name;}
		public String getDescription(){return description;}
		public String getUsrID(){return usr_id;}
		public boolean getSelect(){return selected;}
	}

	/**
	 * This defines the listView adapter used to display the
	 * current members of a group to users that are creating
	 * new events and looking to add attendees 
	 * */
	private class attendeeAdapter extends ArrayAdapter<attendeeEntity> {

		private ArrayList<attendeeEntity> items;
		public attendeeAdapter(Context context, int textViewResourceId, ArrayList<attendeeEntity> items) {
			super(context, textViewResourceId, items);
			this.items = items;
		}

		private class ViewHolder {
			TextView name;
			TextView desc;
			CheckBox selector;
			String id;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder userH = null;
			if (convertView == null) {
				LayoutInflater vi = LayoutInflater.from(this.getContext());
				convertView = vi.inflate(R.layout.calendar_add_event_attendees_listview, null);
			
				userH = new ViewHolder();
				userH.name = (TextView) convertView.findViewById(R.id.attNameText);
				userH.desc = (TextView) convertView.findViewById(R.id.attDescText);
				userH.selector = (CheckBox) convertView.findViewById(R.id.attChkBx);
				convertView.setTag(userH);
			
				userH.selector.setOnClickListener( new View.OnClickListener() {  
				     public void onClick(View v) {  
				         CheckBox cb = (CheckBox) v;
				         attendeeEntity a = (attendeeEntity)cb.getTag();
				         a.setSelect(cb.isSelected());
				     }  
				});
			}
			else
			{
				userH = (ViewHolder) convertView.getTag();
			}
			
			attendeeEntity usrE = items.get(position);
			userH.name.setText(usrE.getName());
			userH.desc.setText(usrE.getDescription());
			userH.selector.setChecked(usrE.getSelect());
			userH.id = usrE.getUsrID();
			userH.selector.setTag(usrE);
			 
			return convertView;
		}
	
		public boolean anySelected(){
			for(int i = 0; i < items.size(); i++){
				if(items.get(i).getSelect())
					return true;
			}
			return false;
		}
		
		public ArrayList<attendeeEntity> getSelectedUsers(){
			ArrayList<attendeeEntity> selected = new ArrayList<attendeeEntity>();
			for(int i = 0; i < items.size(); i++){
				attendeeEntity a = items.get(i);
				if(a.getSelect())
					selected.add(a);
			}
			return selected;
		}
	}

}