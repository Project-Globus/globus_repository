package project.globus.android;

/**
 * This class defines the structure for
 * the child of each expandable list view
 * object used in the calendars event viewer.
 * */
public class Calendar_Event_ChildList {
	private String desc;
	
	public Calendar_Event_ChildList(String dsc){
		desc = dsc;
	}
	
	public String getDesc(){
		return desc;
	}
	public void setDesc(String d){
		this.desc = d;
	}
}