package project.globus.android;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Group_Select_Screen extends Fragment {

	private ListView joinedGrouplv;
	private Button createGroupbtn, joinGroupbtn;
	private GroupSelectListener mListener;
	Context myContext;
	ArrayList<groupEntity> grpList = new ArrayList<groupEntity>();
    private groupAdapter m_adapter;
	
	public Group_Select_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		groupEntity g = new groupEntity("Globus Dev Team", "What better way to work on a project than to work with it.", 1000);
		addGrpToList(g);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_group__select__screen, container, false);
		this.m_adapter = new groupAdapter(myContext, R.layout.joined_group_listview, grpList);
		joinedGrouplv = (ListView) myView.findViewById(R.id.joinedGroups);
		joinedGrouplv.setAdapter(this.m_adapter);
        m_adapter.notifyDataSetChanged();
		
		
		createGroupbtn = (Button) myView.findViewById(R.id.createGroupBtn);
		joinGroupbtn = (Button) myView.findViewById(R.id.joinGroupBtn);
		
		createGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				mListener.OnGroupScreenSelect(1);
			}
		});
		
		joinGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				mListener.OnGroupScreenSelect(0);
			}
		});
		
		joinedGrouplv.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				Intent intent = new Intent(getActivity(), Globus_Application.class);
    			getActivity().startActivity(intent);
			}
		});
		
		return myView;		
	}
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (GroupSelectListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement GroupSelectListener");
		}
		myContext = activity.getApplicationContext();
	}
	
	@Override 
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}
	
	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface GroupSelectListener {
		public void OnGroupScreenSelect(int selection);
	}
	
	public void addGrpToList(groupEntity gE){
		grpList.add(new groupEntity(gE.getName(), gE.getDescription(), gE.getGrpID()));
	}
	
	public class groupEntity{
		
		
		private String name;
		private String description;
		private int grp_id;
		
		public groupEntity(String nme, String desc, int grpID){
			name = nme;
			description = desc; 
			grp_id = grpID;
		}

		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setGroupID(int grpID){grp_id = grpID;}
		
		public String getName(){return name;}
		public String getDescription(){return description;}
		public int getGrpID(){return grp_id;}
	}

private class groupAdapter extends ArrayAdapter<groupEntity> {

    private ArrayList<groupEntity> items;

    public groupAdapter(Context context, int textViewResourceId, ArrayList<groupEntity> items) {
            super(context, textViewResourceId, items);
            this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                LayoutInflater vi = LayoutInflater.from(this.getContext());
                v = vi.inflate(R.layout.joined_group_listview, null);
            }
            groupEntity grpE = items.get(position);
            if (grpE != null) {
                    TextView nameText = (TextView) v.findViewById(R.id.grpNameText);
                    TextView descText = (TextView) v.findViewById(R.id.grpDescText);
                    if( nameText != null){
                    	nameText.setText(grpE.getName());
                    }
                    if( descText != null){
                    	descText.setText(grpE.getDescription());
                    }
            }
            return v;
    }
}
}