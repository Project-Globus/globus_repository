package project.globus.android;

import java.util.ArrayList;
import java.util.Date;

public class Calendar_Event_ParentList {
	
	private String name;
    private String evdate;
    private String evTime;
    private Date evDate;
    
     
    // ArrayList to store child objects
    //private ArrayList<Calendar_Event_ChildList> children;
    public Calendar_Event_ParentList(String nme, Date date){
    	name = nme;
    	evDate = date;
    }
    
    public String getName(){
        return name;}
     
    public void setName(String name){
        this.name = name;}
    
//    public String getDate(){
//        return evdate;}
//     
//    public void setDate(String date){
//        this.evdate = date;}
    
   public String getTime(){
	   return evTime;}
   
   public void setTime(String time){
	   this.evTime = time;}
   
   public void setDate(Date date){
   		this.evDate = date;}
     
   public Date getDate(){
   		return evDate;}
    // ArrayList to store child objects
    //public ArrayList<Calendar_Event_ChildList> getChildren(){
    //    return children;}
     
    //public void setChildren(ArrayList<Calendar_Event_ChildList> children){
    //    this.children = children;}

}