package project.globus.android;

import java.util.ArrayList;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
//import android.app.Fragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

public class Attendance_Eventview extends Fragment {

	private ListView groupEventslv;
	private EventSelectListener mListener;
	Context myContext;
	ArrayList<eventEntity> eventList = new ArrayList<eventEntity>();
	private eventAdapter m_adapter;

	public Attendance_Eventview() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		eventEntity e = new eventEntity("Meeting 1");
		eventEntity e1 = new eventEntity("Meeting 2");
		addEventToList(e);
		addEventToList(e1);

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_attendance__eventview, container, false);
		this.m_adapter = new eventAdapter(myContext, R.layout.attendance_event_listview, eventList);
		groupEventslv = (ListView) myView.findViewById(R.id.eventList);
		groupEventslv.setAdapter(this.m_adapter);
		m_adapter.notifyDataSetChanged();
		
		groupEventslv.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				Attendance_Attendeeview frag = new Attendance_Attendeeview();
		        FragmentTransaction transaction = getFragmentManager().beginTransaction();

		        // Replace whatever is in the fragment_container view with this fragment,
		        // and add the transaction to the back stack so the user can navigate back
		        transaction.replace(R.id.frag_whiteboard, frag);
		        transaction.addToBackStack(null);
		        // Commit the transaction
		        transaction.commit();
			}
		});
		
		return myView;

	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		/*try {
			mListener = (EventSelectListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}*/
		myContext = activity.getApplicationContext();
	}

	
	
	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	
	
	public interface EventSelectListener {
		// TODO: Update argument type and name
		public void onFragmentInteraction(Uri uri);
	}
	
	public void addEventToList(eventEntity eE ){
		eventList.add(new eventEntity(eE.getEventName()));
	}
	
	public class eventEntity{
		private String name;
		
		public eventEntity(String nme){
			name = nme;
		}
		
		public void setEventName (String nme) {name = nme;}
		public String getEventName() {return name;}
		
	}
	
	private class eventAdapter extends ArrayAdapter<eventEntity> {
		
		private ArrayList<eventEntity> items;
		
		public eventAdapter(Context context, int textViewResourceId, ArrayList<eventEntity> items) {
			super(context, textViewResourceId, items);
			this.items = items;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView;
			if (v==null) {
				LayoutInflater vi = LayoutInflater.from(this.getContext());
				v = vi.inflate(R.layout.attendance_event_listview, null);
			}
			eventEntity evntE = items.get(position);
			if(evntE != null) {
				TextView nameText = (TextView) v.findViewById(R.id.eventNameText);
				if(nameText != null) {
					nameText.setText(evntE.getEventName());
				}
			}
			return v;
		}
	}

}
















