package project.globus.android;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

public class Globus_Service extends Service {

	//Binder given to clients
	private final IBinder mBinder = new LocalBinder();
	
	
	public class LocalBinder extends Binder {
		Globus_Service getService() {
			//Return this instance of LocalService so clients can call public methods
			return Globus_Service.this;
		}
	}
	
	//Database code added by Kelsey (3/15/2015) 
	public static Socket socket = null;
	public static PrintWriter toServer = null;
	public static BufferedReader fromServer = null;
	public static Boolean isActive;
	
	
	public Globus_Service() {
		//Blank constructor.
	}
	
	
	@Override
	public void onCreate() {
		try{
			System.out.print("Attempt Connecting... in service\n");
			socket = new Socket("ec2-54-191-216-200.us-west-2.compute.amazonaws.com", 63400);
			System.out.print("Connection made....\n");
			isActive = true;
			//made connection now set up read in and write out 
			toServer = new PrintWriter(new BufferedWriter( new OutputStreamWriter(socket.getOutputStream())));
			fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			System.out.println(toServer);
			//now send a message to the server and then read back the response
		}catch (Exception e) {
			
			System.out.println("Unable to connect .....\n");
			isActive = false;
		}
	}
	
	
	@Override
	public IBinder onBind(Intent intent) {
		System.out.println("Binder starting.");

	    super.onCreate();  
	    System.out.println("IBinder method called");
		return mBinder;
	}
	
	
	public PrintWriter getToServer() {
		return toServer;
	}	
	
	public void setWriterClosed(){
		toServer.flush();
		//toServer.close();
	}
	public void setReaderClosed() throws IOException {
		fromServer.close();
	}
	
	public BufferedReader getFromServer() {
		return fromServer;
	}
	
	public void setCloseSocket() {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void onDestory() {
		System.out.println("On destroy initiated...");

		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		super.onDestroy();
		isActive = false;
		System.out.println("Service destoryed.");
		
	}

}
