package project.globus.android;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Whiteboard_Screen extends Fragment {

	private WhiteboardListener mListener;
	private ListView whiteboardLV;
	Context myContext;
	ArrayList<whiteboardItem> wbList = new ArrayList<whiteboardItem>();
    private whiteboardAdapter m_adapter;
    final SimpleDateFormat dateForm = new SimpleDateFormat("MM/dd/yy");
	final SimpleDateFormat timeForm = new SimpleDateFormat("HH:mm");

    private Button addEve;
    private Button send;
    private Button cancel;
    private EditText subject;
    private EditText body;
	Globus_Service mService = new Globus_Service();

	public Whiteboard_Screen() {
		//Required empty public constructor
	}
	
	@Override 
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override 
	public View onCreateView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.whiteboard_main_screen, container, false);
		this.m_adapter = new whiteboardAdapter(myContext, R.layout.whiteboard_listview, wbList);
		whiteboardLV = (ListView) myView.findViewById(R.id.whiteboardLV);
		whiteboardLV.setAdapter(this.m_adapter);
		updateWhiteBoard();
		
        addEve = (Button) myView.findViewById(R.id.newMessageBtn);
        
        whiteboardLV.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				// custom dialog
	  			final Dialog dialog = new Dialog(getActivity());
	  			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
	  			dialog.setContentView(R.layout.whiteboard_message_view_dialog);
	  			cancel = (Button) dialog.findViewById(R.id.mess_exit);
	  			
	  		// if cancel button is clicked, close the custom dialog
	  			cancel.setOnClickListener(new OnClickListener() {
	  				@Override
	  				public void onClick(View v) {
	  					dialog.dismiss();
	  				}
	  			});
	  			
	  			 whiteboardItem wbI = (whiteboardItem) parent.getItemAtPosition(position);
	                if (wbI != null) {
	        			Toast.makeText(myContext, "subject: " +wbI.getDescription(), Toast.LENGTH_LONG).show();

	                        TextView dateText = (TextView) dialog.findViewById(R.id.mess_date);
	                        TextView subjectText = (TextView) dialog.findViewById(R.id.mess_subject);
	                        TextView descriptionText = (TextView) dialog.findViewById(R.id.mess_body);
	                        ImageView imageObj = (ImageView) dialog.findViewById(R.id.imageView1);
	                        
	                        subjectText.setText(wbI.getName());
	                        if(wbI.getTypeID() == 0){
		                        dateText.setText("Created on: " + dateForm.format(wbI.getDate()));
                        		imageObj.setImageResource(R.drawable.ic_action_message_large);
	                        	descriptionText.setText(wbI.getDescription());
	                        } else if (wbI.getTypeID() == 1){
		                        dateText.setText("Starts on: " +dateForm.format(wbI.getDate()));
                        		imageObj.setImageResource(R.drawable.ic_action_event_large);
	                        	descriptionText.setText("Time: " + timeForm.format(wbI.getDate()) + "\nDescription: " + wbI.getDescription());
	    	                }
	                                                	
	                        
	                }
	                dialog.show();
			}
		});
        
        addEve.setOnClickListener(new OnClickListener() {
        	 
  		  @Override
  		  public void onClick(View arg0) {
   
  			// custom dialog
  			final Dialog dialog = new Dialog(getActivity());
  			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
  			dialog.setContentView(R.layout.whiteboard_message_creation_dialog);
//  			dialog.setTitle("Create a Message");
   
  			// set the custom dialog components
  			subject = (EditText) dialog.findViewById(R.id.msgSubject);
  			body = (EditText) dialog.findViewById(R.id.msgBody);
   
  			send = (Button) dialog.findViewById(R.id.sendMsgBtn);
  			cancel = (Button) dialog.findViewById(R.id.cancelMsgBtn);
  			
  			send.setOnClickListener(new OnClickListener() {
  				@Override
  				public void onClick(View v) {
  					Calendar c = Calendar.getInstance();
  					
  					whiteboardItem temp1 = new whiteboardItem(c.getTime(), 0, subject.getText().toString() , 
  																body.getText().toString(), 0);
  					addEve(temp1);
  					updateWhiteBoard();
  					dialog.dismiss();
  				}
  			});
  			
  			// if cancel button is clicked, close the custom dialog
  			cancel.setOnClickListener(new OnClickListener() {
  				@Override
  				public void onClick(View v) {
  					dialog.dismiss();
  				}
  			});
   
  			dialog.show();
  		  }
  		});
        
        return myView;
	}

	
	//The try catch is commented out because the application fails to load this fragment because of a memory leak.
	//I have NO idea why this is causing the app to fail when it should be working. It's not even getting the catch exception. 
	//I'm not going to implement the back button for the third activity until we figure out why this is happening. 
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		/*try {
			mListener = (WhiteboardListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}*/
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	
	public interface WhiteboardListener {
		public void OnWhiteboard();
	}
	
	/**
	 * This function updates the database with
	 * a new user created message.
	 * */
	private void addEve(whiteboardItem w){
		System.out.println("Beginning Try Catch.");
		String groupID = ((Globus_Application)getActivity()).getGroupID();
		String response = new String();
		
		try{
			System.out.println("Try block started.");
			Calendar c = Calendar.getInstance();
			String allText = new String("getMessages;~;"+  groupID + ";~;" 
										+ (w.getName() + "!#!" + w.getDescription())
										+ ";~;" + "0"+ ";~;" + c.getTimeInMillis());
			System.out.println(allText);
			System.out.println("Sending text.");
			mService.getToServer().println(allText);
			System.out.println("sent to db");

			mService.setWriterClosed();

			System.out.println("writer closed");
			System.out.println("Reading Lines!!!");
			response = mService.getFromServer().readLine();
			System.out.println(response + "Responding!!!!");
			String [] splitResponse = response.split(";~;");
			System.out.println(response + "Responding!!!!");

			if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
				Toast.makeText(myContext, "Error Creating Message. Please try again." , Toast.LENGTH_LONG).show();
			}
			
		}
		catch (IOException e){}
		finally{}	
		
	}

	/**
	 * This function will clear wbList (the list
	 * of current events and messages) and 
	 * re-populate the list by pulling all recent
	 * group messages and events from the database.
	 * */
	public void updateWhiteBoard(){
				
		wbList.clear();
		updateWBEvents();
		updateWBMessages();
		sortWBList();
		m_adapter.notifyDataSetChanged();

		
	}
	private void updateWBEvents(){
			System.out.println("Beginning Try Catch.");
			String groupID = ((Globus_Application)getActivity()).getGroupID();
			String response = new String();
			
			try{
				System.out.println("Try block started.");
				
				String allText = new String("getEvents;~;"+  groupID);
				System.out.println(allText);
				System.out.println("Sending text.");
				mService.getToServer().println(allText);
				System.out.println("sent to db");

				mService.setWriterClosed();

				System.out.println("writer closed");
				System.out.println("Reading Lines!!!");
				response = mService.getFromServer().readLine();
				System.out.println(response + "Responding!!!!");
				String [] splitResponse = response.split(";~;");
				System.out.println(response + "Responding!!!!");

				if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
					Toast.makeText(myContext, "Error retrieving Events." , Toast.LENGTH_LONG).show();
				} else{
					Calendar c = Calendar.getInstance();
					Long week = 1209600000L;
					for(int i = 1; i < splitResponse.length; ){
						whiteboardItem w = new whiteboardItem(new Date(Long.parseLong(splitResponse[i+3])), 
																	1, splitResponse[i+1], 
																	splitResponse[i+2], Integer.parseInt(splitResponse[i+0]));
						Long timeDif = w.getDate().getTime() - c.getTimeInMillis();
						if(c.getTime().before(w.getDate()) && timeDif < 1209600000){
							wbList.add(w);
						}
						i += 6;
					}
				}	
				
			}
			catch (IOException e){}
			finally{}	
	}
	private void updateWBMessages(){
		System.out.println("Beginning Try Catch.");
		String groupID = ((Globus_Application)getActivity()).getGroupID();
		String response = new String();
		
		try{
			System.out.println("Try block started.");
			Calendar c = Calendar.getInstance();
			String allText = new String("getMessages;~;"+  groupID + ";~;" + c.getTimeInMillis());
			System.out.println(allText);
			System.out.println("Sending text.");
			mService.getToServer().println(allText);
			System.out.println("sent to db");

			mService.setWriterClosed();

			System.out.println("writer closed");
			System.out.println("Reading Lines!!!");
			response = mService.getFromServer().readLine();
			System.out.println(response + "Responding!!!!");
			String [] splitResponse = response.split(";~;");
			System.out.println(response + "Responding!!!!");

			if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
				Toast.makeText(myContext, "Error retrieving Messages." , Toast.LENGTH_LONG).show();
			} else{
				for(int i = 1; i < splitResponse.length; ){
					String s = splitResponse[i+3];//as of now, splitResponse[3] contains both the name and description of the message. 
					String[] sP = s.split("!#!");//They are separated by a "!#!"
					whiteboardItem w = new whiteboardItem(new Date(Long.parseLong(splitResponse[i+4])), 
																Integer.parseInt(splitResponse[i+2]), sP[0], 
																sP[1], Integer.parseInt(splitResponse[i]));
					wbList.add(w);
				}
			}	
			
		}
		catch (IOException e){}
		finally{}	
	}
	
	/**
	 * This function, with the help of sortWBlist, partit and swap, will sort the contents of wbList 
	 * based on their date. This implements a basic quicksort on wbList. 
	 * */
	public void sortWBList(){
		sortWBlist(0, wbList.size()-1);
		int i = wbList.size()-1;
		for(int j = 0; j < (wbList.size()-1)/2; j ++){
			swap(i, j);
		}
	}
	public void sortWBlist(int low, int high){
		if(low < high){
			int pivot = partit(low, high);
			sortWBlist(low, pivot);
			sortWBlist(pivot+1, high);			
		}
	}
	
	public int partit(int low, int high){
		whiteboardItem loc = wbList.get(low);
		int wall = low;
		for(int i = low + 1; i < high; i++){
			if(wbList.get(i).getDate().before(loc.getDate())){
				wall += 1;
				swap(i, wall);
			}
		}
		swap(low, wall);
		return wall;
	}
	
	private void swap(int i, int j){
		whiteboardItem temp = wbList.get(i);
		wbList.set(i, wbList.get(j));
		wbList.set(j, temp);
	}
	
	/**
	 * This class defines a whiteboard item. An item used by
	 * the listView to keep track of both the events and 
	 * messages belonging to the current group.
	 * */
	public class whiteboardItem{
		
		private Date dateTime;
		private int type_id;
		private String name;
		private String description;
		private int item_id;
		
		public whiteboardItem(Date d, int typeID, String nme, String desc, int itemID){
			dateTime = d;
			name = nme;
			description = desc; 
			type_id = typeID;
			item_id = itemID;
			
		}
		public void setDate(Date d){dateTime = d;}
		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setTypeID(int typeID){type_id = typeID;}
		public void setItemID(int itemID){item_id = itemID;}
		
		public Date getDate(){return dateTime;}
		public String getName(){return name;}
		public String getDescription(){return description;}
		public int getTypeID(){return type_id;}
		public int getItemID(){return item_id;}
	}

	/**
	 * Defines the whiteboard array adapter for use with the
	 * listview.
	 * */
	private class whiteboardAdapter extends ArrayAdapter<whiteboardItem> {

        private ArrayList<whiteboardItem> items;

        public whiteboardAdapter(Context context, int textViewResourceId, ArrayList<whiteboardItem> items) {
                super(context, textViewResourceId, items);
                this.items = items;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
                View v = convertView;
                if (v == null) {
                    LayoutInflater vi = LayoutInflater.from(this.getContext());
                    v = vi.inflate(R.layout.whiteboard_listview, null);
                }
                whiteboardItem wbI = items.get(position);
                if (wbI != null) {
                        TextView typeText = (TextView) v.findViewById(R.id.typeText);
                        TextView dateText = (TextView) v.findViewById(R.id.dateText);
                        TextView subjectText = (TextView) v.findViewById(R.id.subjectText);
                        TextView descriptionText = (TextView) v.findViewById(R.id.descriptionText);
                        ImageView imageObj = (ImageView) v.findViewById(R.id.imageObj);
                        if (typeText != null) {
                        	if(wbI.getTypeID() == 0){ // the item is a message
                        		typeText.setText("Message"); 
                        		imageObj.setImageResource(R.drawable.ic_action_message_large);
                        	}
                        	else if (wbI.getTypeID() == 1){// the item is an event
                        		typeText.setText("Event");
                        		imageObj.setImageResource(R.drawable.ic_action_event_large);
                        	}
                        	if( dateText != null){
                        		dateText.setText(dateForm.format(wbI.getDate()));
                        	}
                        	if( subjectText != null){
                        		subjectText.setText(timeForm.format(wbI.getDate()));
                        	}
                        	if( descriptionText != null){
                        		descriptionText.setText(wbI.getName() + ": " + wbI.getDescription());
                        	}
                        }	
                        
                }
                return v;
        }
	}
	}
