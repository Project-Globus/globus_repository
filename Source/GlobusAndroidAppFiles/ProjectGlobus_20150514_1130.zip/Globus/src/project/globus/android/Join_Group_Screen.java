package project.globus.android;

import java.io.IOException;

import project.globus.android.Group_Select_Screen.groupEntity;
import project.globus.android.Login_Screen.LoginSelectListener;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class Join_Group_Screen extends Fragment {
	
	private EditText groupIDET;
	private Button joinExistingGroupbtn;
	private JoinGroupListener mListener;
	
	Context myContext;
	Globus_Group_Selection_Screen joinGroupActivity = new Globus_Group_Selection_Screen();
	
	
	public Join_Group_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override 
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.groupselect_join__group__screen, container, false);
		 
		groupIDET = (EditText) myView.findViewById(R.id.groupIDeditText);
		joinExistingGroupbtn = (Button) myView.findViewById(R.id.JoinExistingGroupBtn);
		
		/*
		 * public void onClick(View view) {
		 * Intent intent = new Intent(getActivity(), Globus_Application.class);
		 * getActivity().startActivity(intent); 
		 * }
		 * */
		
		joinExistingGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				String groupID = groupIDET.getText().toString();
				
//				try{
//					System.out.println("Try block started.");
//					//Server Code Time ************************************************************************
//					String allText = new String("membership;~;"+ );
//					System.out.println(allText);
//					System.out.println("Sending text.");
//					joinGroupActivity.getToServer().println(allText);
//					System.out.println("sent to db");
//
//					joinGroupActivity.setWriterClosed();
//
//					System.out.println("writer closed");
//
//					String response = joinGroupActivity.getFromServer().readLine();
//
//					String [] splitResponse = response.split(";~;");
//					System.out.println(response);
//
//
//					//TODO: while loop for error correction 
//					if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
//						Toast.makeText(myContext, "Error retrieving group list. oops..." , Toast.LENGTH_LONG).show();
//					} else{
//					
//					}
//
//				
//				
//				}
//				catch (IOException e){}
//				finally{}		
//						
//				//No More Server Code *********************************************************************
//				
////				boolean credsValid = true;
////				if(credsValid) {
////					Intent intent = new Intent(getActivity(), Globus_Application.class);
////        			getActivity().startActivity(intent);
////					Toast.makeText(myContext, "Credentials are valid!! Join sucessfull." , Toast.LENGTH_LONG).show();
////					}
////				else {
////					Toast.makeText(myContext, "Credentials are NOT VALID. Try again." , Toast.LENGTH_LONG).show();
////					}
			}
		});
		
		return myView;
	}
	

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (JoinGroupListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	
	public interface JoinGroupListener {
		public void OnJoinGroup();
	}
}