package project.globus.android;

import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.app.Fragment;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.IOException;

import project.globus.android.Globus_Service.LocalBinder;


public class Create_Account_Screen extends Fragment {

	//Declare Buttons and Text fields we will use.
	private EditText nameText, emailText, passText;
	private Button submitB, cancelB;
	private CreateAccountListener mListener;
	Context myContext;
	Globus_Welcome_Screen activityOneA = (Globus_Welcome_Screen)getActivity();

	Globus_Service mService = new Globus_Service();
	boolean mBound = false;
	

	public Create_Account_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
	}
	
	
	/********************************************************************************
	 * This creates the buttons and text fields that the user will interact with on the 
	 * create new account fragment. The user will have a submit and cancel button which 
	 * both have listeners and name, email, and password text fields they can enter 
	 * information in. 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_create__account__screen,
				container, false);
		
		//submitB is attatched to the submit button in the fragment.
		//when it is pressed, the app will check to see if the given 
		//email hasn't been used yet, and it will add the user to the 
		//database if it hasn't. 
		submitB = (Button) myView.findViewById(R.id.yesButton);
		
		//cancelB is attached to the cancel button in the fragment.
		//as you might guess, the soul purpose of this button is to 
		//back out to the welcome screen
		cancelB = (Button) myView.findViewById(R.id.noButton);
		
		//These text fields are where the user enters in his/her desired
		//name, email and password for the new account
		nameText = (EditText) myView.findViewById(R.id.nameInput); 
		emailText = (EditText) myView.findViewById(R.id.EAInput); 
		passText = (EditText) myView.findViewById(R.id.passInput); 

		submitB.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		
        		
        		if(nameText.getText().toString().matches("") || emailText.getText().toString().matches("") || passText.getText().toString().matches("")) {
        			Toast.makeText(myContext, "Please enter a name, email and password." , Toast.LENGTH_LONG).show();
        			return;
        		}
        		
        		String allText = new String("register;~;"+
        									nameText.getText().toString()+";~;  ;~;"+													
        									emailText.getText().toString()+";~;"+
        									passText.getText().toString()+";~;");
        		
        		System.out.println("AllText  " + allText);
        		
        		String response = new String();

        		try {
                    // Send the input to the server
                    mService.getToServer().println(allText);
                    mService.setWriterClosed();
                    response = mService.getFromServer().readLine();
              
                    String [] splitResponse = response.split(";~;");
                    
                    
                    if(splitResponse[0].matches("(.*)exists.")){
                    	Toast.makeText(myContext, "User name already in use. Please use different email." , Toast.LENGTH_LONG).show();
                    } else if(splitResponse[0].matches("(.*)not allowed(.*)")){
                    	Toast.makeText(myContext, "Something went wrong. Please try again." , Toast.LENGTH_LONG).show();
                    } else{
                    	Toast.makeText(myContext, "User name valid. Account created!" , Toast.LENGTH_LONG).show();
                    	
                    	Intent intent = new Intent(getActivity(), Globus_Group_Selection_Screen.class);
	        			
	        			intent.putExtra("membership", splitResponse[2]);
	        			
	        			getActivity().startActivity(intent);
	        			getActivity().finish();
                    }
                    
                    
                } catch (IOException e) {
					System.out.println("ERROR IN SEND OR RECEIVE!!!!!!!!......");
					e.printStackTrace();
				} finally {}
        			mListener.OnCreateAccountSelect();
        			
        			
        	}
		});
		
		cancelB.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		//as stated above. Upon being clicked, the app displays the welcome screen.
        		mListener.OnCreateAccountSelect();        		
        	}
		});  
		return myView;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (CreateAccountListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement Create_Account_Listener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}


	public interface CreateAccountListener {
		public void OnCreateAccountSelect();
	}

}
