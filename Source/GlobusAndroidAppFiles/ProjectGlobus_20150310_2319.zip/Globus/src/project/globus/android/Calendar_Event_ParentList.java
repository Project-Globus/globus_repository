package project.globus.android;

import java.util.ArrayList;

public class Calendar_Event_ParentList {
	
	private String name;
    private String evDate;
    
     
    // ArrayList to store child objects
    private ArrayList<Calendar_Event_ChildList> children;
     
    public String getName(){
        return name;}
     
    public void setName(String name){
        this.name = name;}
    public String getEvDate(){
        return evDate;}
     
    public void setEvDate(String ED){
        this.evDate = ED;}
     
     
    // ArrayList to store child objects
    public ArrayList<Calendar_Event_ChildList> getChildren(){
        return children;}
     
    public void setChildren(ArrayList<Calendar_Event_ChildList> children){
        this.children = children;}

}
