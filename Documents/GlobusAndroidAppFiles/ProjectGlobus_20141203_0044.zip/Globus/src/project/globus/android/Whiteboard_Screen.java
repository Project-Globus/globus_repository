package project.globus.android;

import project.globus.android.Join_Group_Screen.JoinGroupListener;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

public class Whiteboard_Screen extends Fragment {
	
	private WhiteboardListener mListener;
	private ListView whiteboardLV;
	Context myContext;
	
	public Whiteboard_Screen() {
		//Required empty public constructor
	}
	
	@Override 
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override 
	public View onCreateView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_whiteboard__screen, container, false);
		
		//TODO: This will be the whiteboard cursor call to the database to display all the messages
		
		return myView;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (WhiteboardListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	
	public interface WhiteboardListener {
		public void OnWhiteboard();
	}
	
}
