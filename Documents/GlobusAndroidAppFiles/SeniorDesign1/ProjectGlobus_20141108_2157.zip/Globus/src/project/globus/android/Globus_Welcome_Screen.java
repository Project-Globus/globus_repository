//Project Globus Main 
//Project Globus Members: David Crane, Kelsey Crea, Jesse Miller, Taylor Olsen 
//Project Globus is a group management applications for groups to manage members and work together via phone app. 
//This project was last updated on October 30, 2014


package project.globus.android;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;

/*****************************************************************************************
 * This is main starting activity (activity 1) that starts with a welcome screen. 
 * @author Team Globus 
 * comment updated October 30, 2014
 ****************************************************************************************/
public class Globus_Welcome_Screen extends Activity implements
  project.globus.android.Welcome_Screen.WelcomeScreenListener,
  project.globus.android.Create_Account_Screen.CreateAccountListener, 
  project.globus.android.Login_Screen.LoginSelectListener{

	
/****************************************************************************************
 * The welcome screen is the first fragment to load for the user. Go to Welcome_Screen.java 
 * to see more details.
 * 
 * Comment updated October 30, 2014
 ***************************************************************************************/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_globus__welcome__screen);
		if (savedInstanceState == null) {
			getFragmentManager().beginTransaction()
					.add(R.id.container, new Welcome_Screen()).commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.globus__welcome__screen, menu);
		return true;
	}
	
	/********************************************************************************
	 * Yeah we haven't done anything for these button items or spoken about them....
	 * We can make these functional at some point but it's not a huge rush right now 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/

	//TODO: All of these buttons; home, back, etc. 

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


	
	/********************************************************************************
	 * This is load the login fragment. For more details go to Login_Screen.java 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public void OnLoginSelect() {        
        Welcome_Screen frag = new Welcome_Screen();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.container, frag);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();	
		
	}

	
	/********************************************************************************
	 * This will load the 'Create a new account' fragment. For more details 
	 * go to Create_Account_Screen.java
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public void OnCreateAccountSelect() {        
        Welcome_Screen frag = new Welcome_Screen();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.container, frag);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();	
	}

	
	
	/*******************************************************************************
	 * This will determine which fragment (login or create a new account) will be loaded 
	 * depending what selection is passed into this function. 
	 * 
	 * Comment updated October 30, 2014
	 ********************************************************************************/
	@Override
	public void OnWelcomeScreenSelect(int selection) {
		if(selection == 0){
			Login_Screen frag = new Login_Screen();
	        FragmentTransaction transaction = getFragmentManager().beginTransaction();

	        // Replace whatever is in the fragment_container view with this fragment,
	        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.container, frag);
	        transaction.addToBackStack(null);
	        // Commit the transaction
	        transaction.commit();
		}
		else if(selection == 1){
			Create_Account_Screen frag = new Create_Account_Screen();
	        FragmentTransaction transaction = getFragmentManager().beginTransaction();

	        // Replace whatever is in the fragment_container view with this fragment,
	        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.container, frag);
	        transaction.addToBackStack(null);
	        // Commit the transaction
	        transaction.commit();
		}
	}
}
