package project.globus.android;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
//import android.app.Fragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Settings_Screen extends Fragment {
	
	Button privilegesBtn, manageCalendarsBtn, leaveGroupBtn;
	Context myContext;

	private onSettingsFragInteractionListener mListener;

	public Settings_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_settings__screen, container, false);
		
		privilegesBtn = (Button) myView.findViewById(R.id.privilegesButton);
		privilegesBtn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				// TODO: This is what happens with the privileges. I am thinking about a
				// doing a pop up dialog.
			}
		});
		
		manageCalendarsBtn =(Button) myView.findViewById(R.id.manageCalendarsButton);
        manageCalendarsBtn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO: This is the manage calendars settings. Jesse, not sure how this would
				// interact with your stuff. Might be simple database interaction.
			}
        });
        
        leaveGroupBtn =(Button) myView.findViewById(R.id.leaveGroup);
        leaveGroupBtn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO: This will be a database interaction piece.
			}
        });
		
		return myView;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		/*try {
			mListener = (onSettingsFragInteractionListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}*/
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	public interface onSettingsFragInteractionListener {
		public void onSettingsFragFragmentInteraction();
	}

}
