package project.globus.android;

import java.io.IOException;
import java.util.ArrayList;

import project.globus.android.Globus_Service.LocalBinder;
import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.app.Fragment;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Group_Select_Screen extends Fragment {

	private ListView joinedGrouplv;
	private Button createGroupbtn, joinGroupbtn;
	private GroupSelectListener mListener;
	Context myContext;
	ArrayList<groupEntity> grpList = new ArrayList<groupEntity>();
    private groupAdapter m_adapter;
	
    Globus_Group_Selection_Screen groupListActivity = (Globus_Group_Selection_Screen)getActivity();
    
	Globus_Service mService = new Globus_Service();
	boolean mBound = false;

	

//	@Override 
//	public void onStart(){
//		if(!mBound){
//			super.onStart();
//			//Bind to LocalService
//			Intent intent = new Intent(getActivity(), Globus_Service.class);
//			getActivity().bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
//			System.out.println("onStart of Services Called");
//		}
//	}
//	
//	@Override
//	public  void onStop(){
//		super.onStop();
//		//Unbind from the service
//		if(mBound) {
//			getActivity().unbindService(mConnection);
//			mBound = false;
//		}
//	}
    
	public Group_Select_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		groupEntity g = new groupEntity("Sunrise Valley Co.", "Keeping the world safe from the inevitable since 1969.", "1000");
		groupEntity g1 = new groupEntity("DnD: The Fall of Neverwinter", "Let's make sure we actually stay in contact and finish our game this time", "1001");
		groupEntity g2 = new groupEntity("Titan Dance Crew", "Official group for the Titan Dance Crew", "1002");
		addGrpToList(g);
		addGrpToList(g1);
		addGrpToList(g2);
	}
	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_group__select__screen, container, false);
		System.out.println("On create started Group Select");

		this.m_adapter = new groupAdapter(myContext, R.layout.joined_group_listview, grpList);
		
		joinedGrouplv = (ListView) myView.findViewById(R.id.joinedGroups);
		joinedGrouplv.setAdapter(this.m_adapter);
       
		m_adapter.notifyDataSetChanged();
		createGroupbtn = (Button) myView.findViewById(R.id.createGroupBtn);
		joinGroupbtn = (Button) myView.findViewById(R.id.joinGroupBtn);
		
		
		System.out.println("Beginning Try Catch.");
		String userID = ((Globus_Group_Selection_Screen)getActivity()).getMemberID();
		String response = new String();
		
		try{
			System.out.println("Try block started.");
			
			String allText = new String("membership;~;"+  userID);
			System.out.println(allText);
			System.out.println("Sending text.");
			mService.getToServer().println(allText);
			System.out.println("sent to db");

			mService.setWriterClosed();

			System.out.println("writer closed");
			System.out.println("Reading Lines!!!");
			response = mService.getFromServer().readLine();
			System.out.println(response + "Responding!!!!");
			String [] splitResponse = response.split(";~;");
			System.out.println(response + "Responding!!!!");


			//TODO: while loop for error correction 
			if(splitResponse[0].matches("(.*) RETRIEVING INFORMATION FROM (.*)")){
				Toast.makeText(myContext, "Error retrieving group list. oops..." , Toast.LENGTH_LONG).show();
			} else{
				for(int i = 1; i < splitResponse.length; ){
					groupEntity g = new groupEntity(splitResponse[i], splitResponse[i + 3], splitResponse[i + 1]);
					addGrpToList(g);
					i += 7;
				}
			}		
		}
		catch (IOException e){}
		finally{}		
	
		createGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				mListener.OnGroupScreenSelect(1);
			}
		});
		
		joinGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				mListener.OnGroupScreenSelect(0);
			}
		});
		
		joinedGrouplv.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				Intent intent = new Intent(getActivity(), Globus_Application.class);
    			getActivity().startActivity(intent);
			}
		});
		
		
		return myView;		
	}
	

//	//Defines callbacks for service binding, passed to bindService() 
//		private ServiceConnection mConnection = new ServiceConnection() {
//			
//			@Override 
//			public void onServiceConnected(ComponentName className, IBinder service){
//				//We've bound to LocalService, cast the IBinder and get LocalService instance
//				LocalBinder binder = (LocalBinder) service;
//				mService = binder.getService();
//				mBound = true;
//			}
//			
//			public void onServiceDisconnected(ComponentName className){
//				//This is called when the connection with the service has been 
//				//unexpectedly disconnected -- that is, its process crashed. 
//				mService = null; 
//				mBound = false;
//			}
//		};
	
	
	
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (GroupSelectListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement GroupSelectListener");
		}
		myContext = activity.getApplicationContext();
	}
	
	@Override 
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}
	

	public interface GroupSelectListener {
		public void OnGroupScreenSelect(int selection);
	}
	
	
	
	
	//Adapter code for listview of groups
	public void addGrpToList(groupEntity gE){
		grpList.add(new groupEntity(gE.getName(), gE.getDescription(), gE.getGrpID()));
	}
	
	public class groupEntity{
		
		
		private String name;
		private String description;
		private String grp_id;
		
		public groupEntity(String nme, String desc, String grpID){
			name = nme;
			description = desc; 
			grp_id = grpID;
		}

		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setGroupID(String grpID){grp_id = grpID;}
		
		public String getName(){return name;}
		public String getDescription(){return description;}
		public String getGrpID(){return grp_id;}
	}

	private class groupAdapter extends ArrayAdapter<groupEntity> {

		private ArrayList<groupEntity> items;

		public groupAdapter(Context context, int textViewResourceId, ArrayList<groupEntity> items) {
			super(context, textViewResourceId, items);
			this.items = items;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView;
			if (v == null) {
				LayoutInflater vi = LayoutInflater.from(this.getContext());
				v = vi.inflate(R.layout.joined_group_listview, null);
			}
			groupEntity grpE = items.get(position);
			if (grpE != null) {
				TextView nameText = (TextView) v.findViewById(R.id.grpNameText);
				TextView descText = (TextView) v.findViewById(R.id.grpDescText);
				if( nameText != null){
					nameText.setText(grpE.getName());
				}
				if( descText != null){
					descText.setText(grpE.getDescription());
				}
			}
			return v;
		}
	}
}