package project.globus.android;

import project.globus.android.Login_Screen.LoginSelectListener;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Create_Group_Screen extends Fragment {

	private EditText newGroupName, userEmail, psswd, verifypsswd;
	private Button submitbtn;
	private CreateGroupListener mListener;
	Context myContext;

	public Create_Group_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_create__group__screen, container, false);
		
		newGroupName = (EditText) myView.findViewById(R.id.newGroupNameEditText);
		userEmail = (EditText) myView.findViewById(R.id.userEmailEditText);
		psswd = (EditText) myView.findViewById(R.id.psswdEditText);
		verifypsswd = (EditText) myView.findViewById(R.id.verifypsswdEditText);
		submitbtn = (Button) myView.findViewById(R.id.submitNewGroupBtn);
		
		submitbtn.setOnClickListener(new OnClickListener() {
			@Override 
			public void onClick(View view) {
				//There will be a check with the database to make sure this group can be added
				//There will be a check to make sure the text in psswd and verifypsswd are the same
				//There will be a check to make sure the user has entered a valid email address that is in the system
				
				Boolean credsValid = true;
				if(credsValid == true) Toast.makeText(myContext, "Credentials are valid!! New Group sucessfull." , Toast.LENGTH_LONG).show();
				else Toast.makeText(myContext, "Credentials are NOT VALID. New Group not sucessfull." , Toast.LENGTH_LONG).show();
			}
		});
		return myView;
	}
	

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (CreateGroupListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}


	public interface CreateGroupListener {
		public void OnCreateGroup();
	}

}
