package project.globus.android;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.Vector;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Events;
import android.app.Fragment;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

/**
 * This fragment creates a calendar view, and populates it via a CalendarContract. 
 * This CalendarContract pulls calendars from the phone, which are being created/updated
 * via the event database.
 */
public class Calendar_Screen extends Fragment {
	// ** Generic Parameters left in case we want to use them
	//Rename parameter arguments, choose names that match
	// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
	//private static final String ARG_PARAM1 = "param1";
	//private static final String ARG_PARAM2 = "param2";

	// ** Generic Parameters left in case we want to use them
	//private String mParam1;
	//private String mParam2;
	
	//at the moment, currentGroup will contain whatever information we
	//need to determine which group calendar we need to display. This
	//will probably be either the group ID or the group name.
	private String currentGroup;
	Context myContext;
	

	private onCalendarFragInteractListener mListener;

	public Calendar_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (getArguments() != null) {
			//mParam1 = getArguments().getString(ARG_PARAM1);
			//mParam2 = getArguments().getString(ARG_PARAM2);
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_calendar__screen, container,
				false);
		
		Toast.makeText(myContext, "Calendar Button Pushed and attempting to load." , Toast.LENGTH_SHORT).show();
		return myView;
	}

	// TODO: Rename method, update argument and hook method into UI event
	public void onButtonPressed(Uri uri) {
		if (mListener != null) {
			mListener.onCalendarFragInteraction(uri);
		}
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (onCalendarFragInteractListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface onCalendarFragInteractListener {
		// TODO: Update argument type and name
		public void onCalendarFragInteraction(Uri uri);
	}
	
	
	/**
	 * This function will check to see if the
	 * current group's calendar already has
	 * a local version running on the user's
	 * system. If it does, the system returns
	 * the calendars ID. If it doesn't, the system returns
	 * a -1. 
	 */
	public String calendarIDCheck(){
		String [] columns = new String [] {Calendars.NAME, Calendars._ID};
		Cursor c = myContext.getContentResolver().query(Calendars.CONTENT_URI, 
														columns, 
														Calendars.VISIBLE + " = 1", 
														null, 
														Calendars.NAME + " ASC");
		if(c.moveToFirst()){
			do{
				String calName = c.getString(0);
				if(calName.equals(currentGroup + "DB"))
					return c.getString(1);
			}while (c.moveToNext());
		}
		return "-1";
		
	}
	
	/**
	 * This function will be called upon the first time
	 * a user accesses a specific group's calendar.
	 * This function simply creates a new sub-calendar
	 * on the user's device.
	 */
	public void insertNewCalendar(){
		ContentValues values = new ContentValues();
		values.put(Calendars.ACCOUNT_NAME, currentGroup + "DB");
		values.put(Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL);
		values.put(Calendars.NAME, currentGroup + " Calendar");
		values.put(Calendars.CALENDAR_DISPLAY_NAME, currentGroup + " Calendar");
		values.put(Calendars.CALENDAR_COLOR, 0xffff0000);
		values.put(Calendars.CALENDAR_ACCESS_LEVEL, Calendars.CAL_ACCESS_OWNER);
		values.put( Calendars.OWNER_ACCOUNT, "some.account@googlemail.com");
		values.put(Calendars.CALENDAR_TIME_ZONE, TimeZone.getDefault().getID());
		values.put(Calendars.SYNC_EVENTS, 1);
		Uri.Builder builder = CalendarContract.Calendars.CONTENT_URI.buildUpon();
		builder.appendQueryParameter( Calendars.ACCOUNT_NAME, "com." + currentGroup + "DB");
		builder.appendQueryParameter( Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL);
		builder.appendQueryParameter(CalendarContract.CALLER_IS_SYNCADAPTER, "true");
		Uri uri = myContext.getContentResolver().insert(builder.build(), values);
	}
	
	/**
	 * This function will query all existing
	 * events for the current group, and feed
	 * any events not already known into the 
	 * local calendar. 
	 */
	public void updateCalendar(){
		/*CREATE TABLE globus.Events
       time_start BIGINT,
       time_end BIGINT,
       name VARCHAR(255),
       description VARCHAR(255),
    -> description VARCHAR(2500),
    -> PRIMARY KEY (event_id),
    -> FOREIGN KEY (cal_id) REFERENCES globus.Calendar(cal_id)
    -> );*/
		
		/*
		 * So, If it's possible, it would be best if we change the events table slightly.
		 * It would be much easier to interface with the calendar if we change time_start
		 * and time_end into time_start_hour, time_start_minute, time_end_hour and 
		 * time_end_minute. I will be coding as if this change was made, in order to save
		 * time and so I won't have to write parsers -JAM*/
		ArrayList<eventItem> eventList = new ArrayList<eventItem>();

		
		/***************** IMPORTANT CODE ********************
		/*This is where we create a cursor that will query all event 
		 * entries, and write them into the eventList. Un-comment the 
		 * following code, and add in necessary extras, once the data 
		 * base is ready for use. This code will create a query that
		 * will list all of the current events listed with the calendar 
		 * on the globus database. it will then take this query and 
		 * feed it into the eventList vector.
		String [] columns = new String [] { globus.Events.time_start_hour, globus.Events.time_start_minute,
											globus.Event.time_end_hour, globus.Event.time_end_minute,
											globus.Event.event_id, globus.Event.name, 
											globus.Event.description, globus.Event.cal_id};
		Cursor eventCurs = myContext.getContentResolver().query(GLOBUS_DATABASE_URI, 
																columns, 
																globus.Events.cal_id + " = " + globus.Calendar.cal_id, 
																null, 
																Calendars.NAME + " ASC"); 
		if(eventCurs.moveToFirst()){
			do{
				eventItem tempEv = new eventItem(eventCurs.getInt(0), eventCurs.getInt(1),
				 									eventCurs.getInt(2), eventCurs.getInt(3),
				 									eventCurs.getInt(4), eventCurs.getString(5),
				 									eventCurs.getString(6), eventCurs.getInt(7));
				 eventList.add(tempEv);
			
			}while (eventCurs.moveToNext());
		}
		 * */
		
		/********** more important code *********
		 * this code will find the calendar ID for the groups
		 * calendar, create a list of events the current local
		 * calendar knows about, and then adds any events not
		 * already in the calendar to the calendar. again, until
		 * we know more about our local database, we won't be
		 * able to implement much of this.
		String grpCalendarID = calendarIDCheck();
		
		String [] calEventsColumns = new String [] {Events.event_id};
		
		Cursor calEvents = myContext.getContentResolver().query(Calendars.CONTENT_URI, 
																calEventsColumns, 
															    Integer.toString(globus.Events.cal_id) + " = " + grpCalendarID, 
																null, 
																globus.Events.name + " ASC"); 
		
		while (!eventList.isEmpty()){
			eventItem eve = eventList.get(0);
			if(eve.getCalID() is not in calEvents){
				addEvent(eve, grpCalendarID);
				eventList.remove(0);
			}
		}
		*/
	}
	
	
	/**
	 * This function converts a given eventItem into an
	 * intent, and then uses this intent to add the 
	 * event to the calendar.
	 */
	public void addEvent(long calID, eventItem event){
		GregorianCalendar calDateStart = new GregorianCalendar(event.getYear(), event.getMonth(), event.getDay());
		GregorianCalendar calDateEnd = new GregorianCalendar(event.getYear(), event.getMonth(), event.getDay());
		calDateStart.set(Calendar.HOUR, event.getTimeStartHour());
		calDateStart.set(Calendar.MINUTE, event.getTimeStartHour());
		calDateEnd.set(Calendar.HOUR, event.getTimeEndHour());
		calDateEnd.set(Calendar.MINUTE, event.getTimeEndHour());
		
		Intent calIntent = new Intent(Intent.ACTION_INSERT).setData(Events.CONTENT_URI)
                .setData(Events.CONTENT_URI)
               .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, calDateStart.getTimeInMillis())
           .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, calDateEnd.getTimeInMillis())
               .putExtra(Events.TITLE, event.getName())
               .putExtra(Events.HAS_ALARM, 1)
               .putExtra(Events.DESCRIPTION, event.getDescription())
               .putExtra(Events.CALENDAR_ID, calID)
               .putExtra(Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
			

                startActivity(calIntent);
	}
	
	public class eventItem{
		private int month, day, year; // NEED TO UPDATE REST OF CODE TO WORK WITH THIS.
		private int time_start_hour;
		private int time_start_minute;
		private int time_end_hour;
		private int time_end_minute;
		private int event_id;
		private String name;
		private String description;
		private int cal_id;
		
		public eventItem(int m, int d, int y, int tSh, int tSm, int tEh, int tEm, int evID, String nme, String desc, int calID){
			month = m;
			day = d;
			year = y;
			time_start_hour = tSh;
			time_start_minute = tSm;
			time_end_hour = tEh;
			time_end_minute = tEm;
			event_id = evID;
			name = nme;
			description = desc; 
			cal_id = calID;
		}
		public void setMonth(int m){month = m;}
		public void setDay(int d){day = d;}
		public void setYear(int y){year = y;}
		public void setTimeStartHour(int tSh){time_start_hour = tSh;}
		public void setTimeStartMinute(int tSm){time_start_minute = tSm;}
		public void setTimeEndHour(int tEh){time_end_hour = tEh;}
		public void setTimeEndMinute(int tEm){time_end_minute = tEm;}
		public void setEventID(int evID){event_id = evID;}
		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setCalID(int calID){cal_id = calID;}
		
		public int getMonth(){return month;}
		public int getDay(){return day;}
		public int getYear(){return year;}
		public int getTimeStartHour(){return time_start_hour;}
		public int getTimeStartMinute(){return time_start_minute;}
		public int getTimeEndHour(){return time_end_hour;}
		public int getTimeEndMinute(){return time_end_minute;}
		public int getEventID(){return event_id;}
		public String getName(){return name;}
		public String getDescription(){return description;}
		public int getCalID(){return cal_id;}

	}
}
