package project.globus.android;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * This fragment creates a calendar view, and populates it via a CalendarContract. 
 * This CalendarContract pulls calendars from the phone, which are being created/updated
 * via the event database.
 */
public class Calendar_Screen extends Fragment {
	// ** Generic Parameters left in case we want to use them
	//Rename parameter arguments, choose names that match
	// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
	//private static final String ARG_PARAM1 = "param1";
	//private static final String ARG_PARAM2 = "param2";

	// ** Generic Parameters left in case we want to use them
	//private String mParam1;
	//private String mParam2;
	
	//at the moment, currentGroup will contain whatever information we
	//need to determine which group calendar we need to display. This
	//will probably be either the group ID or the group name.
	private String currentGroup;
	

	private onCalendarFragInteractListener mListener;

	public Calendar_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (getArguments() != null) {
			//mParam1 = getArguments().getString(ARG_PARAM1);
			//mParam2 = getArguments().getString(ARG_PARAM2);
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_calendar__screen, container,
				false);
		
		return myView;
	}

	// TODO: Rename method, update argument and hook method into UI event
	public void onButtonPressed(Uri uri) {
		if (mListener != null) {
			mListener.onCalendarFragInteraction(uri);
		}
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (onCalendarFragInteractListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface onCalendarFragInteractListener {
		// TODO: Update argument type and name
		public void onCalendarFragInteraction(Uri uri);
	}

	public void insertNewCalendar(){
		
	}
	
}
