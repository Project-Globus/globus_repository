/** Automatically generated file. DO NOT MODIFY */
package edu.cosc4760.webView;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}