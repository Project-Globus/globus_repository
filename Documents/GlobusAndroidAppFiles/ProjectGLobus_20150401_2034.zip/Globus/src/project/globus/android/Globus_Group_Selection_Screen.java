package project.globus.android;

import project.globus.android.Globus_Service.LocalBinder;
import android.app.Activity;
import android.app.FragmentTransaction;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;


/************************************************************************
 * This is the second activity (activity 2) that starts by loading the  *
 * group selection page                                                 *
 * @author Team Globus                                                  *
 * comment updated November 10, 2014                                    *
 ************************************************************************/

public class Globus_Group_Selection_Screen extends Activity implements
	project.globus.android.Group_Select_Screen.GroupSelectListener,
	project.globus.android.Join_Group_Screen.JoinGroupListener,
	project.globus.android.Create_Group_Screen.CreateGroupListener{	

	Globus_Service mService;
	boolean mBound = false;
	public String getMemberID(){
		return getIntent().getStringExtra("membership");
	}
    
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_group__screen);
		System.out.println("Starting intent calling stuff");
		Intent intent = new Intent(this, Globus_Service.class);
		getApplicationContext().bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
		if(savedInstanceState == null) {
			Group_Select_Screen newFrag = new Group_Select_Screen();
			//newFrag.setArguments(getIntent().getExtras());
			getFragmentManager().beginTransaction()
				.add(R.id.container2, newFrag).commit();
		}
		
		//Added to receive messages from database
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		System.out.println("Activity 2 started with services");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		getMenuInflater().inflate(R.menu.group__screen, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if(id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void OnGroupScreenSelect(int selection) {
			if(selection == 0) {
				Join_Group_Screen frag = new Join_Group_Screen();
				FragmentTransaction transaction = getFragmentManager().beginTransaction();
				transaction.replace(R.id.container2, frag);
				transaction.addToBackStack(null);
				transaction.commit();
			} else {
				Create_Group_Screen frag = new Create_Group_Screen();
				FragmentTransaction transaction = getFragmentManager().beginTransaction();
				transaction.replace(R.id.container2, frag);
				transaction.addToBackStack(null);
				transaction.commit();
			}
	}

	@Override
	public void OnJoinGroup() {
		Join_Group_Screen frag = new Join_Group_Screen();
		FragmentTransaction transaction = getFragmentManager().beginTransaction();
		transaction.replace(R.id.container2, frag);
		transaction.addToBackStack(null);
		transaction.commit();	
	}

	@Override
	public void OnCreateGroup() {
		Create_Group_Screen frag = new Create_Group_Screen();
		FragmentTransaction transaction = getFragmentManager().beginTransaction();
		transaction.replace(R.id.container2, frag);
		transaction.addToBackStack(null);
		transaction.commit();
		
	}
	
	//Defines callbacks for service binding, passed to bindService() 
	private ServiceConnection mConnection = new ServiceConnection() {
				
		@Override 
		public void onServiceConnected(ComponentName className, IBinder service){
			//We've bound to LocalService, cast the IBinder and get LocalService instance
			LocalBinder binder = (LocalBinder) service;
			mService = binder.getService();
			mBound = true;
		}
				
		public void onServiceDisconnected(ComponentName className){
			//This is called when the connection with the service has been 
			//unexpectedly disconnected -- that is, its process crashed. 
			mService = null; 
			mBound = false;
		}
	};
}
