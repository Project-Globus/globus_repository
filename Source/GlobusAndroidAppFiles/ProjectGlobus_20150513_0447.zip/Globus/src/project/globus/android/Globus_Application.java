package project.globus.android;

import project.globus.android.Globus_Service.LocalBinder;
import android.support.v4.app.FragmentTransaction;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.FragmentActivity;

public class Globus_Application extends FragmentActivity implements
project.globus.android.Whiteboard_Button_Screen.WhiteBoardButtonsListener,
project.globus.android.Calendar_Screen.onCalendarFragInteractListener,
project.globus.android.Google_Drive_Screen.onGoogleDriveFragInteractListener,
project.globus.android.Whiteboard_Screen.WhiteboardListener{

	Globus_Service mService;
	boolean mBound = false;
	public String getGroupID(){
		return getIntent().getStringExtra("groupID");
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState)  {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_globus__application);
		Intent intent = new Intent(this, Globus_Service.class);
		getApplicationContext().bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
		if (savedInstanceState == null) {
		}
	}

	//TODO: This should be changed to a case statement later to look cleaner. 
	@Override
	public void OnButtonsListener(int selection) {
		if(selection == 0){
			Calendar_Screen frag = new Calendar_Screen();
	        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
	        
	        	 // Replace whatever is in the fragment_container view with this fragment,
		        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.frag_whiteboard, frag);
		    transaction.addToBackStack(null);
		    // Commit the transaction
		    transaction.commit();
		}
		else if(selection == 1){
			//This is for the Attendence button, the fragments haven't been created yet. This is for senior design and not mobile.
			
			Attendance_Eventview frag = new Attendance_Eventview();
	        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

	        // Replace whatever is in the fragment_container view with this fragment,
	        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.frag_whiteboard, frag);
	        transaction.addToBackStack(null);
	        // Commit the transaction
	        transaction.commit();
		}
		else if(selection == 2) {
			//This is for the Blanket Messages button, the fragments haven't been created yet. This is for senior design and not mobile.
			
			Whiteboard_Screen frag = new Whiteboard_Screen();
	        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

	        // Replace whatever is in the fragment_container view with this fragment,
	        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.frag_whiteboard, frag);
	        transaction.addToBackStack(null);
	        // Commit the transaction
	        transaction.commit();
		}
		else if(selection == 3){
			//This is for the Google Drive button. 
			Google_Drive_Screen frag = new Google_Drive_Screen();
	        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

	        // Replace whatever is in the fragment_container view with this fragment,
	        // and add the transaction to the back stack so the user can navigate back
	        transaction.replace(R.id.frag_whiteboard, frag);
	        transaction.addToBackStack(null);
	        // Commit the transaction
	        transaction.commit();
			
		}
		else if(selection == 4){
			//This is for the Settings button.
			Settings_Screen frag = new Settings_Screen();
			FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

		       // Replace whatever is in the fragment_container view with this fragment,
		       // and add the transaction to the back stack so the user can navigate back
		       transaction.replace(R.id.frag_whiteboard, frag);
		       transaction.addToBackStack(null);
		       // Commit the transaction
		       transaction.commit();
		}
		
	}

	@Override
	public void onCalendarFragInteraction(Uri uri) {
		// TODO Auto-generated method stub

		/* I don't know where you guys want this to lead. I'm not sure what all Jesse needs to connect to the Calendar. 
		 * Let me know and I'll link this. 
		 * 
		 */
		
		
		/*Setting frag = new Settings();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.application, frag);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();*/
		
	}

	@Override
	public void onGoogleDriveFragInteraction() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void OnWhiteboard() {
		//The OnWhiteboard method is called whenever a user
		//selects a calendar event and wants to view more 
		//about the event.
		OnButtonsListener(0);
		
	}

	//Defines callbacks for service binding, passed to bindService() 
		private ServiceConnection mConnection = new ServiceConnection() {
					
			@Override 
			public void onServiceConnected(ComponentName className, IBinder service){
				//We've bound to LocalService, cast the IBinder and get LocalService instance
				LocalBinder binder = (LocalBinder) service;
				mService = binder.getService();
				mBound = true;
			}
					
			public void onServiceDisconnected(ComponentName className){
				//This is called when the connection with the service has been 
				//unexpectedly disconnected -- that is, its process crashed. 
				mService = null; 
				mBound = false;
			}
		};
	
}
