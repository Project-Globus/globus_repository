package project.globus.android;

import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class Calendar_ExpandableListAdapter extends BaseExpandableListAdapter{

	 public ArrayList<Calendar_Event_ParentList> groupItem;
	 public ArrayList<Calendar_Event_ChildList> tempChild;
	 public ArrayList<Object> Childtem = new ArrayList<Object>();
	 public LayoutInflater minflater;
	 public Activity activity;
	
	public Calendar_ExpandableListAdapter(ArrayList<Calendar_Event_ParentList> grList, ArrayList<Object> childItem) {
		  groupItem = grList;
		  Childtem = childItem;
	 }

	public void setInflater(LayoutInflater mInflater, Activity act) {
	  minflater = mInflater;
	  activity = act;
	}
	 
	 @Override
	 public void onGroupCollapsed(int groupPosition) {
	  super.onGroupCollapsed(groupPosition);
	 }

	 @Override
	 public void onGroupExpanded(int groupPosition) {
	  super.onGroupExpanded(groupPosition);
	 }
	
	@Override
	public int getGroupCount() {
		// TODO Auto-generated method stub
		return groupItem.size();
	}
	//

	@SuppressWarnings("unchecked")
	@Override
	public int getChildrenCount(int groupPosition) {
		// TODO Auto-generated method stub
		return ((ArrayList<Calendar_Event_ChildList>) Childtem.get(groupPosition)).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		// TODO Auto-generated method stub
		return groupItem.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return ((ArrayList<Calendar_Event_ChildList>)Childtem.get(groupPosition)).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if (convertView == null) {
			   convertView = minflater.inflate(R.layout.calendar_listview_parent, null);
		}
		TextView eveDate = (TextView) convertView.findViewById(R.id.calEventDTtext);
		TextView eveName = (TextView) convertView.findViewById(R.id.calEventNtext);
		eveDate.setText(groupItem.get(groupPosition).getDate() + " " + groupItem.get(groupPosition).getTime());
		eveName.setText(groupItem.get(groupPosition).getName());
//		convertView.setOnClickListener(new OnClickListener() {
//			   @Override
//			   public void onClick(View v) {
//			    Toast.makeText(activity, "Event clicked",
//			      Toast.LENGTH_SHORT).show();
//			   }
//		});
		return convertView;
	}

	@SuppressWarnings("unchecked")
	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if (convertView == null) {
			   convertView = minflater.inflate(R.layout.calendar_listview_child, null);
		}
		tempChild = (ArrayList<Calendar_Event_ChildList>) Childtem.get(groupPosition);
		TextView eveDesc = (TextView) convertView.findViewById(R.id.calEDtext);
		eveDesc.setText(tempChild.get(childPosition).getDesc());
		
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return true;
	}

}
