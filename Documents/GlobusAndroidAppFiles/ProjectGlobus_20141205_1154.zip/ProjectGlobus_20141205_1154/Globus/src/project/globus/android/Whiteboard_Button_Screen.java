package project.globus.android;

import project.globus.android.Join_Group_Screen.JoinGroupListener;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


public class Whiteboard_Button_Screen extends Fragment {
	
	
	private Button Calendarbtn, Attendancebtn, BlanketMsgbtn, GoogleDrivebtn, Settingsbtn;
	private WhiteBoardButtonsListener mListener;
	Context myContext;

	public Whiteboard_Button_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	//Who wrote these listeners? At least type out view instead of just v. Come on guys....
	@Override 
	public View onCreateView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_whiteboard__button__screen, container, false);
		

		Calendarbtn = (Button) myView.findViewById(R.id.calendarBtn);
		Calendarbtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				mListener.OnButtonsListener(0);
				Toast.makeText(myContext, "Calendar Button Pushed!" , Toast.LENGTH_SHORT).show();
			}
			});

		Attendancebtn = (Button) myView.findViewById(R.id.attendanceBtn);
		Attendancebtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(myContext, "Attendance Button Pushed!" , Toast.LENGTH_SHORT).show();
				
			}
			
		});
		
		BlanketMsgbtn = (Button) myView.findViewById(R.id.blanketMessageBtn);
		BlanketMsgbtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(myContext, "Message Button Pushed!" , Toast.LENGTH_SHORT).show();
				
			}
			
		});
		
		GoogleDrivebtn = (Button) myView.findViewById(R.id.googleDriveBtn);
		GoogleDrivebtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(myContext, "Google Drive Button Pushed!" , Toast.LENGTH_SHORT).show();
				
			}
			
		});
		
		Settingsbtn = (Button) myView.findViewById(R.id.settingsBtn);
		Settingsbtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(myContext, "Settings Button Pushed!" , Toast.LENGTH_SHORT).show();
				
			}
			
		});
		return myView;
	}

	

	//The try catch is commented out because the application fails to load this fragment because of a memory leak.
	//I have NO idea why this is causing the app to fail when it should be working. It's not even getting the catch exception. 
	//I'm not going to implement the back button for the third activity until we figure out why this is happening. 
	
	//Okay, I figured it out. The activity wasn't implementing "project.globus.android.Whiteboard_Button_Screen.WhiteBoardButtonsListener"
	//so the whole app stopped working. Good note, when creating a new activity, you MUST include this line even just to test or it won't work. 
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (WhiteBoardButtonsListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}



	
	public interface WhiteBoardButtonsListener {
		public void OnButtonsListener(int selection);
	}

	
}
