package project.globus.android;

import project.globus.android.Globus_Service.LocalBinder;
import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.app.Fragment;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Welcome_Screen extends Fragment {

	private WelcomeScreenListener mListener;
	Context myContext;
	Globus_Service mService;
	boolean mBound = false;
	
	
	
	public Welcome_Screen() {
		// Required empty public constructor
	}

	
	@Override 
	public void onStart(){
		super.onStart();
		//Bind to LocalService
		Intent intent = new Intent(getActivity(), Globus_Service.class);
		getActivity().bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
		System.out.println("onStart of Services Called in welcome screen frag");
		Toast.makeText(getActivity(), "Inside of Welcome screen onStart", Toast.LENGTH_SHORT).show();
		
	}
	
	@Override
	public  void onStop(){
		super.onStop();
		//Unbind from the service
		if(mBound) {
			getActivity().unbindService(mConnection);
			mBound = false;
			System.out.println("moved away from welcome screen frag. Services unbind");
		}
	}
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	/********************************************************************************
	 * This sets up the buttons and listeners for the login button on the welcome screen. 
	 * 
	 * Comment updated November 2, 2014
	 ********************************************************************************/
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		View myView = inflater.inflate(R.layout.fragment_globus__welcome__screen, container, false);
		
		Button logButton, createAccButton;
		
		logButton = (Button) myView.findViewById(R.id.LoginButton);
		createAccButton = (Button) myView.findViewById(R.id.CreateAccButton);
		
		logButton.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		mListener.OnWelcomeScreenSelect(0);
        	}
		});
		
	
		
		createAccButton.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		mListener.OnWelcomeScreenSelect(1);
        	}
		});

		return myView;
		
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (WelcomeScreenListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement WelcomeScreenListener");
		}
		myContext = activity.getApplicationContext();

	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	public interface WelcomeScreenListener {
		public void OnWelcomeScreenSelect(int selection);
	}
	
	//Defines callbacks for service binding, passed to bindService() 
	private ServiceConnection mConnection = new ServiceConnection() {
		
		@Override 
		public void onServiceConnected(ComponentName className, IBinder service){
			//We've bound to LocalService, cast the IBinder and get LocalService instance
			LocalBinder binder = (LocalBinder) service;
			mService = binder.getService();
			mBound = true;
		}
		
		public void onServiceDisconnected(ComponentName className){
			//This is called when the connection with the service has been 
			//unexpectedly disconnected -- that is, its process crashed. 
			mService = null; 
			mBound = false;
		}
	};

}
