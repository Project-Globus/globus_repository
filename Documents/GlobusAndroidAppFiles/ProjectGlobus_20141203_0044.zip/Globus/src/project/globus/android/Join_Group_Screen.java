package project.globus.android;

import project.globus.android.Login_Screen.LoginSelectListener;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class Join_Group_Screen extends Fragment {
	
	private EditText groupIDET;
	private Button joinExistingGroupbtn;
	private JoinGroupListener mListener;
	Context myContext;
	
	public Join_Group_Screen() {
		//Required empty public constructor
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override 
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_join__group__screen, container, false);
		
		groupIDET = (EditText) myView.findViewById(R.id.groupIDeditText);
		joinExistingGroupbtn = (Button) myView.findViewById(R.id.JoinExistingGroupBtn);
		
		joinExistingGroupbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				String groupID = groupIDET.getEditableText().toString();
				
				boolean credsValid = true;
				if(credsValid) {
					Toast.makeText(myContext, "Credentials are valid!! Join sucessfull." , Toast.LENGTH_LONG).show();
					}
				else {
					Toast.makeText(myContext, "Credentials are NOT VALID. Try again." , Toast.LENGTH_LONG).show();
					}
			}
		});
		
		return myView;
	}
	

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (JoinGroupListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	
	public interface JoinGroupListener {
		public void OnJoinGroup();
	}
}