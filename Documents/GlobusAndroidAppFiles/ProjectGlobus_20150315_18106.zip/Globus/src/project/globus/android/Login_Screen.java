package project.globus.android;


import java.io.IOException;

import project.globus.android.R.string;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login_Screen extends Fragment {
	
	//Declare buttons/text fields we will be using.
	private EditText emailAd, passW;
	private Button submitB, backB;
	private LoginSelectListener mListener;
	Context myContext;


	public Login_Screen() {
		// Required empty public constructor
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View myView = inflater.inflate(R.layout.fragment_login__screen, container,
				false);
		
		
		/********************************************************************************
		 * These are all of the fields that the user can interact with while logging into 
		 * the application. The user has the ability to enter an email address, and password. 
		 * The user can click a submit button, or a back button. Both the submit and back 
		 * buttons have listeners that have been created below. 
		 * 
		 * Comment updated October 30, 2014
		 ********************************************************************************/
		//emailAd corresponds with the input box for the users email address
		emailAd = (EditText) myView.findViewById(R.id.emailInput); 
		
		//passW corresponds with the input box for the users password
		passW = (EditText) myView.findViewById(R.id.LogPassInput);
		
		//submitB corresponds with the submit button (which should check to see if user
		//credentials are valid, make a toast verifying that they are (for now) and return to the welcome screen
		submitB = (Button) myView.findViewById(R.id.LogButton);
		
		//backB corresponds with the back button (which should take the user back to the welcome screen)
		backB = (Button) myView.findViewById(R.id.LogBackButton);
		
		
		//TODO: db comment 
		/********************************************************************************
		 * This will be a comment about how the button/fields interact with the database.
		 * 
		 * Comment updated October 30, 2014
		 ********************************************************************************/
		submitB.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		//TODO: interact button with db
        		/********************************************************************
        		 * David,															*
        		 * This is where the code for the "Submit" button will go.			*
        		 * What I've done is set up the if-else statement for if the 		*
        		 * user credentials provided are valid. All this requires database	*
        		 * wise is a check to see if there is a user associated 			*
        		 * with the provided email address and if the password matches that *
        		 * user's listed password.											*
        		 ********************************************************************/
        		
        		//userEmail and userPass variables are set to equal whatever is currently 
        		//in the email and password text fields on the login screen
        		String userEmail = emailAd.getEditableText().toString();
        		String userPass = passW.getEditableText().toString();
        		
        		//credsValid states whether the provided email and password are a real login email and correct
        		//password. This should be updated based on the database query
        
        		String allText = new String("login;~;"+
        									emailAd.getText().toString()+";~;"+
        									passW.getText().toString()+";~;");
        		
        		
        		if(emailAd.getText().toString().matches("") || passW.getText().toString().matches("")) {
        			Toast.makeText(myContext, "Please enter both a email and password." , Toast.LENGTH_LONG).show();
        			return;
        		}
        		
        		
        		System.out.println("AllText "+ allText);
        		String response = new String();
        		Globus_Welcome_Screen activityLogin = (Globus_Welcome_Screen)getActivity();
        		
	        	try{
	        		activityLogin.getToServer().println(allText);
	        		System.out.println("sent to db");
	        		activityLogin.setWriterClosed();
	        		System.out.println("writer closed");
	        		response = activityLogin.getFromServer().readLine();
	        		
	        		System.out.println(response);
	        		
	        		String [] splitResponse = response.split(";~;");
	        		System.out.println(splitResponse[0]);
	        		
	        		if(splitResponse[0].matches("(.*) Please register.")){
	        			Toast.makeText(myContext, "Incorrect email. Please register." , Toast.LENGTH_LONG).show();
	        		} else if (splitResponse[0].matches("(.*) password combination exists.(.*)")){
	        			Toast.makeText(myContext, "Incorrect password. Please try again." , Toast.LENGTH_LONG).show();
	        		} else {
	        			Toast.makeText(myContext, "Credentials are valid!! Login sucessfull." , Toast.LENGTH_LONG).show();
	        		}
	        		
	        		
	        		
	        	} catch (IOException e) {
	        		System.out.println("ERROR IN SEND OR RECEIVE!!!!!!!!......");
					e.printStackTrace();
	        	}
        		
        		/*if(credsValid){
        			//Makes toast stating creds are valid
        			Toast.makeText(myContext, "Credentials are valid!! Login sucessfull." , Toast.LENGTH_LONG).show();
        			Intent intent = new Intent(getActivity(), Globus_Group_Selection_Screen.class);
        			/*
        			 * There will be intents line in here to pass username and password to second activity. 
        			 * 
        			 * intent.putExtra("userEmail", userEmail);
        			 * intent.putExtra("userPass", userPass);
        			 * 
        			 */
        			//getActivity().startActivity(intent);
        			//getActivity().finish();        	
        		//}
        		//else{
        			//Makes toast stating creds are not valid
        			//Toast.makeText(myContext, "Credentials are invalid. Please re-enter email and password." , Toast.LENGTH_LONG).show();
        		//}
        	}

		});
		
		backB.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View view) {
        		//as stated above. Upon being clicked, the app displays the welcome screen.
        		mListener.OnLoginSelect();
        	}
		});
		
		
		
		return myView;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (LoginSelectListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface LoginSelectListener {
		// TODO: Update argument type and name
		public void OnLoginSelect();
	}

}
