package project.globus.android;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import com.google.gwt.resources.client.impl.ImageResourcePrototype.Bundle;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.widget.Toast;

public class Globus_Service extends Service {

	//Database code added by Kelsey (3/15/2015) 
	public static Socket socket = null;
	public static PrintWriter toServer = null;
	public static BufferedReader fromServer = null;
	public static Boolean isActive;
	
	
	@Override
	public void onStart(Intent intent, int startId){
		super.onStart(intent, startId);
		System.out.println("Service started....yay!");
		
	}
	
	@Override
	public void onCreate() {
		try{
			System.out.print("Attempt Connecting... in service\n");
			socket = new Socket("ec2-54-191-216-200.us-west-2.compute.amazonaws.com", 63400);
			System.out.print("Connection made....\n");
			isActive = true;
			//made connection now set up read in and write out 
			toServer = new PrintWriter(new BufferedWriter( new OutputStreamWriter(socket.getOutputStream())));
			fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			//now send a message to the server and then read back the response
			
		}catch (Exception e) {
			
			System.out.println("Unable to connect .....\n");
			isActive = false;
		}
	}
	
	
	@Override
	public IBinder onBind(Intent intent) {
	    super.onCreate();  
		return null;
	}
	
	public void onDestory() {
		
		try {
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		super.onDestroy();
		isActive = false;
		System.out.println("Service destoryed.");
	}

}
