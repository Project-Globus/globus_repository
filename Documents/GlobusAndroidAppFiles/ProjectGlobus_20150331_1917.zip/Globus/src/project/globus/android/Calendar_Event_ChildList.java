package project.globus.android;

public class Calendar_Event_ChildList {
	private String desc;
	
	public String getDesc(){
		return desc;
	}
	public void setDesc(String d){
		this.desc = d;
	}
}
