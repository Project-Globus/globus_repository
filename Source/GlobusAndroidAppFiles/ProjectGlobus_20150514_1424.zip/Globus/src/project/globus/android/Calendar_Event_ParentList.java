package project.globus.android;

import java.util.ArrayList;
import java.util.Date;

/**
 * This class defines the structure for
 * the Parent object for each expandable 
 * list view object used in the calendars 
 * event viewer. It also keeps track of
 * the calendar ID for use when adding
 * new events to the calendar.
 * */
public class Calendar_Event_ParentList {
	
	private String name;
    private Date evStartDate;
    private Date evEndDate;
    private String evID;
    private String calID;
    
     
    // ArrayList to store child objects
    //private ArrayList<Calendar_Event_ChildList> children;
    public Calendar_Event_ParentList(String nme, Date dateS, Date dateE, String eID, String cID){
    	name = nme;
    	evStartDate = dateS;
    	evEndDate = dateE;
    	evID = eID;
    	calID = cID;
    }
    
    public String getName(){return name;}
     
    public void setName(String name){this.name = name;}
    
    public String getEvID(){return evID;}
     
    public void setEvID(String e){this.evID = e;}
    
    public String getCalID(){return calID;}
     
    public void setCalID(String c){this.calID = c;}
   
   public void setStDate(Date date){this.evStartDate = date;}
     
   public Date getStDate(){return evStartDate;}
   
   public void setEnDate(Date date){this.evEndDate = date;}
    
  public Date getEnDate(){return evEndDate;}

}