/** Automatically generated file. DO NOT MODIFY */
package project.globus.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}