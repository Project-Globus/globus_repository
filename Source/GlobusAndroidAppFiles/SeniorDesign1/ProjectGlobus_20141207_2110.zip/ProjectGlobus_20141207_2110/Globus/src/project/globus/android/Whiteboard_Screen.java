package project.globus.android;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import project.globus.android.Calendar_Screen.eventItem;
import project.globus.android.Join_Group_Screen.JoinGroupListener;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Whiteboard_Screen extends Fragment {

	private WhiteboardListener mListener;
	private ListView whiteboardLV;
	Context myContext;
	ArrayList<whiteboardItem> wbList = new ArrayList<whiteboardItem>();
    private whiteboardAdapter m_adapter;
    private Runnable viewWB;
    private int nextID = 1000;
    
    private Button addEve;
    private Button send;
    private Button cancel;
    private EditText subject;
    private EditText body;
	
	public Whiteboard_Screen() {
		//Required empty public constructor
	}
	
	@Override 
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		whiteboardItem tempWB = new whiteboardItem(12, 5, 14, 0, "Keep it up", "you're doing good!", 0001, " ");
		whiteboardItem tempWBevent = new whiteboardItem(12, 5, 14, 1, "Keep it up", "you're doing good!", 0002, "8:50-11:30pm");
		addToWBlist(tempWB);
		addToWBlist(tempWBevent);
	}
	
	@Override 
	public View onCreateView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState) {
		View myView = inflater.inflate(R.layout.fragment_whiteboard__screen, container, false);
		this.m_adapter = new whiteboardAdapter(myContext, R.layout.whiteboard_listview, wbList);
		ListView listView = (ListView) myView.findViewById(R.id.whiteboardLV);
		listView.setAdapter(this.m_adapter);
        m_adapter.notifyDataSetChanged();

        addEve = (Button) myView.findViewById(R.id.newMessageBtn);
        
        addEve.setOnClickListener(new OnClickListener() {
        	 
  		  @Override
  		  public void onClick(View arg0) {
   
  			// custom dialog
  			final Dialog dialog = new Dialog(getActivity());
  			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
  			dialog.setContentView(R.layout.message_creation_layout);
//  			dialog.setTitle("Create a Message");
   
  			// set the custom dialog components
  			subject = (EditText) dialog.findViewById(R.id.msgSubject);
  			body = (EditText) dialog.findViewById(R.id.msgBody);
   
  			send = (Button) dialog.findViewById(R.id.sendMsgBtn);
  			cancel = (Button) dialog.findViewById(R.id.cancelMsgBtn);
  			
  			send.setOnClickListener(new OnClickListener() {
  				@Override
  				public void onClick(View v) {
  					Calendar c = Calendar.getInstance();
  					
  					whiteboardItem temp1 = new whiteboardItem(c.get(c.MONTH) + 1, c.get(c.DAY_OF_MONTH), c.get(c.YEAR) - 2000, 
  																0, subject.getText().toString() , 
  																body.getText().toString(), nextID, " ");
  					nextID = nextID + 1;
  					addToWBlist(temp1);
  					m_adapter.notifyDataSetChanged();
  					dialog.dismiss();
  				}
  			});
  			
  			// if cancel button is clicked, close the custom dialog
  			cancel.setOnClickListener(new OnClickListener() {
  				@Override
  				public void onClick(View v) {
  					dialog.dismiss();
  				}
  			});
   
  			dialog.show();
  		  }
  		});
        
        return myView;
	}

	
	//The try catch is commented out because the application fails to load this fragment because of a memory leak.
	//I have NO idea why this is causing the app to fail when it should be working. It's not even getting the catch exception. 
	//I'm not going to implement the back button for the third activity until we figure out why this is happening. 
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		/*try {
			mListener = (WhiteboardListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}*/
		myContext = activity.getApplicationContext();
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	
	public interface WhiteboardListener {
		public void OnWhiteboard();
	}

	public void updateWhiteBoard(){
		/** This block of code will (one day) pull all of the event items for the given group
		 * and place them into the item list for the group's whiteboard.
		 String [] columns = new String [] {month, day, year, globus.Event.event_id, globus.Event.name, 
				globus.Event.description};
			Cursor eventCurs = myContext.getContentResolver().query(GLOBUS_DATABASE_URI, 
									columns, 
									globus.Events.cal_id + " = " + globus.Calendar.cal_id, 
									null, 
									Calendars.NAME + " ASC"); 
		if(eventCurs.moveToFirst()){
			do{
				whiteboardItem tempIt = new whiteboardItem(eventCurs.getInt(0), eventCurs.getInt(1),
							eventCurs.getInt(2), 1, eventCurs.getString(4), eventCurs.getString(5), 
							eventCurs.getInt(3));
				wbList.add(tempIt);

			}while (eventCurs.moveToNext());
		}*/
		
		/** We also need to add a block here that will query the messages database,
		 * and place them in a cursor. assuming this is here, these messages are then
		 * fed into the wbList as well.		
		}*/
		
		//call sortWBlist();
		//call displayWBlist();
		//this.getActivity().runOnUiThread(returnRes); 
        m_adapter.notifyDataSetChanged();

		
	}
	
	/**
	 * this function will sort the contents of wbList 
	 * based on their date (the starting date for an
	 * event, or the creation date of a message) from
	 * most recent, to oldest message. in case of events, it will display the soonest
	 * ones first and then the later events lower in the feed. 
	 * */
	public void sortWBlist(){
		
	}
	
	public void addToWBlist(whiteboardItem w){
		wbList.add(new whiteboardItem(w.getMonth(), w.getDay(), w.getYear(), w.getTypeID(),
				w.getName(), w.getDescription(), w.getItemID(), w.getSubject()));
	}
	
	public class whiteboardItem{
		
		private int month, day, year; // NEED TO UPDATE REST OF CODE TO WORK WITH THIS.
//		private int time_start_hour;
//		private int time_start_minute;
//		private int time_end_hour;
//		private int time_end_minute;
		private int type_id;
		private String name;
		private String description;
		private int item_id;
		private String subject; //In the case of an event, the subject will be the time start - time end
		
		public whiteboardItem(int m, int d, int y, int typeID, String nme, String desc, int itemID, String sub){
			month = m;
			day = d;
			year = y;
			name = nme;
			description = desc; 
			type_id = typeID;
			item_id = itemID;
			subject = sub;
			
		}
		public void setMonth(int m){month = m;}
		public void setDay(int d){day = d;}
		public void setYear(int y){year = y;}
		public void setName(String nme){name = nme;}
		public void setDescription(String desc){description = desc;}
		public void setTypeID(int typeID){type_id = typeID;}
		public void setItemID(int itemID){item_id = itemID;}
		public void setSubject(String sub){subject = sub;}
		
		public int getMonth(){return month;}
		public int getDay(){return day;}
		public int getYear(){return year;}
		public String getName(){return name;}
		public String getDescription(){return description;}
		public int getTypeID(){return type_id;}
		public int getItemID(){return item_id;}
		public String getSubject(){return subject;}
	}
	
	
	
	private class whiteboardAdapter extends ArrayAdapter<whiteboardItem> {

        private ArrayList<whiteboardItem> items;

        public whiteboardAdapter(Context context, int textViewResourceId, ArrayList<whiteboardItem> items) {
                super(context, textViewResourceId, items);
                this.items = items;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
                View v = convertView;
                if (v == null) {
                    LayoutInflater vi = LayoutInflater.from(this.getContext());
                    v = vi.inflate(R.layout.whiteboard_listview, null);
                }
                whiteboardItem wbI = items.get(position);
                if (wbI != null) {
                        TextView typeText = (TextView) v.findViewById(R.id.typeText);
                        TextView dateText = (TextView) v.findViewById(R.id.dateText);
                        TextView subjectText = (TextView) v.findViewById(R.id.subjectText);
                        TextView descriptionText = (TextView) v.findViewById(R.id.descriptionText);
                        ImageView imageObj = (ImageView) v.findViewById(R.id.imageObj);
                        if (typeText != null) {
                        	if(wbI.getTypeID() == 0){ // the item is a message
                        		typeText.setText("Message"); 
                        		imageObj.setImageResource(R.drawable.ic_action_message_large);
                        	}
                        	else if (wbI.getTypeID() == 1){// the item is an event
                        		typeText.setText("Event");
                        		imageObj.setImageResource(R.drawable.ic_action_event_large);
                        	}
                        	if( dateText != null){
                        		dateText.setText(wbI.getMonth() + "/" + wbI.getDay() + "/" + wbI.getYear());
                        	}
                        	if( subjectText != null){
                        		subjectText.setText(wbI.getSubject());
                        	}
                        	if( descriptionText != null){
                        		descriptionText.setText(wbI.getDescription());
                        	}
                        }	
                        
                }
                return v;
        }
	}
	}
