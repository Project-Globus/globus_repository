package project.globus.android;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;


/************************************************************************
 * This is the second activity (activity 2) that starts by loading the  *
 * group selection page                                                 *
 * @author Team Globus                                                  *
 * comment updated November 10, 2014                                    *
 ************************************************************************/

public class Globus_Group_Selection_Screen extends Activity implements
	project.globus.android.Group_Select_Screen.GroupSelectListener,
	project.globus.android.Join_Group_Screen.JoinGroupListener,
	project.globus.android.Create_Group_Screen.CreateGroupListener{	

	//Database code added by Kelsey (3/4/2015 @ 12:31) based on battlebot code
		private static Socket socket = null;
		private static PrintWriter toServer = null;
		private static BufferedReader fromServer = null;
		Thread myNet;
		
	
	public String getMemberID(){
		return getIntent().getStringExtra("membership");
	}
    
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_group__screen);
		
		if(savedInstanceState == null) {
			Group_Select_Screen newFrag = new Group_Select_Screen();
			//newFrag.setArguments(getIntent().getExtras());
			getFragmentManager().beginTransaction()
				.add(R.id.container2, newFrag).commit();
		}
		
		//creates thread to establish db connection
		//This will get deleted when services are up and running and working correctly
		/*doNetwork stuff = new doNetwork();
		myNet = new Thread(stuff);
		myNet.start();
		*/
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		getMenuInflater().inflate(R.menu.group__screen, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if(id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void OnGroupScreenSelect(int selection) {
			if(selection == 0) {
				Join_Group_Screen frag = new Join_Group_Screen();
				FragmentTransaction transaction = getFragmentManager().beginTransaction();
				transaction.replace(R.id.container2, frag);
				transaction.addToBackStack(null);
				transaction.commit();
			} else {
				Create_Group_Screen frag = new Create_Group_Screen();
				FragmentTransaction transaction = getFragmentManager().beginTransaction();
				transaction.replace(R.id.container2, frag);
				transaction.addToBackStack(null);
				transaction.commit();
			}

	}

	@Override
	public void OnJoinGroup() {
		Join_Group_Screen frag = new Join_Group_Screen();
		FragmentTransaction transaction = getFragmentManager().beginTransaction();
		transaction.replace(R.id.container2, frag);
		transaction.addToBackStack(null);
		transaction.commit();	
	}

	@Override
	public void OnCreateGroup() {
		Create_Group_Screen frag = new Create_Group_Screen();
		FragmentTransaction transaction = getFragmentManager().beginTransaction();
		transaction.replace(R.id.container2, frag);
		transaction.addToBackStack(null);
		transaction.commit();
		
	}
	
	//Database code added by Kelsey Crea (3/4/2015 @ 12:34pm) based on battlebot code 
	
	/*class doNetwork implements Runnable {
		public void run() {
			//get port number 
			//get host address
			
			try{
				System.out.print("Attempt Connecting...\n");
				socket = new Socket("ec2-54-191-216-200.us-west-2.compute.amazonaws.com", 63400);
				
				//made connection now set up read in and write out 
				toServer = new PrintWriter(new BufferedWriter( new OutputStreamWriter(socket.getOutputStream())));
				fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				
				//now send a message to the server and then read back the response
				
			}catch (Exception e) {
				
				System.out.println("Unable to connect .....\n");
			
			}			
			
		}
	}
	
	public PrintWriter getToServer() {
		return toServer;
	}
	
	public Socket getSocket() {
		return socket;
	}
	
	public void setWriterClosed(){
		toServer.flush();
		//toServer.close();
	}
	public void setReaderClosed() throws IOException {
		fromServer.close();
	}
	
	public BufferedReader getFromServer() {
		return fromServer;
	}
	

	
	public void setCloseSocket() {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}*/
}
